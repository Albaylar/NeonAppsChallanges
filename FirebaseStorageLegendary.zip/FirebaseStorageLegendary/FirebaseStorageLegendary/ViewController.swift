import UIKit
import SDWebImage

class ViewController: UIViewController {

    let label = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        NotificationCenter.default.addObserver(self, selector: #selector(updateLabel(notification:)), name: Notification.Name("DownloadURLNotification"), object: nil)
    }

    func setupUI() {
        label.text = "Download URL"
        label.textColor = .systemRed
        label.textAlignment = .center
        label.numberOfLines = 0

        view.addSubview(label)
        label.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(200)
            make.right.left.width.equalToSuperview().inset(20)
            make.height.equalTo(50)
        }

        let button = UIButton()
        button.setTitle("Download Mascot Photo", for: .normal)
        button.backgroundColor = .systemRed
        button.layer.cornerRadius = 20
        button.tintColor = .black
        button.addTarget(self, action: #selector(downloadButtonPressed), for: .touchUpInside)

        view.addSubview(button)
        button.snp.makeConstraints { make in
            make.top.equalTo(label.snp.bottom).offset(50)
            make.right.left.width.equalToSuperview().inset(50)
            make.height.equalTo(70)
        }
    }

    @objc func updateLabel(notification: Notification) {
        if let userInfo = notification.userInfo,
            let downloadURL = userInfo["downloadURL"] as? URL {
            label.text = downloadURL.absoluteString
        }
    }

    @objc private func downloadButtonPressed() {
        guard let imageURL = label.text else { return }
        downloadImage(from: imageURL) { result in
            switch result {
            case .success(let image):
                self.saveImageToPhotoLibrary(image)
                print("Image downloaded and saved successfully.")
            case .failure(let error):
                print("Error downloading image: \(error.localizedDescription)")
            }
        }
    }

    private func downloadImage(from imageURL: String, completion: @escaping (Result<UIImage, Error>) -> Void) {
        guard let url = URL(string: imageURL) else {
            completion(.failure(NSError(domain: "AppErrorDomain", code: -1, userInfo: nil)))
            return
        }

        SDWebImageDownloader.shared.downloadImage(with: url, options: [], progress: nil) { (image, data, error, finished) in
            if let error = error {
                completion(.failure(error))
            } else if let image = image {
                completion(.success(image))
            } else {
                completion(.failure(NSError(domain: "AppErrorDomain", code: -1, userInfo: nil)))
            }
        }
    }

    func saveImageToPhotoLibrary(_ image: UIImage) {
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
    }

    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            print("Error saving image: \(error.localizedDescription)")
        } else {
            print("Image saved successfully.")
        }
    }
}

