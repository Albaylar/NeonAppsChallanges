//
//  UploadVC.swift
//  FirebaseStorageLegendary
//
//  Created by Furkan Deniz Albaylar on 20.11.2023.
//
import UIKit
import FirebaseStorage
import FirebaseFirestore


class UploadVC: UIViewController {
    
    let photo = UIImageView()
    let feedVC = ViewController()
    var completion: ((URL) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    func setupUI(){
        photo.image = UIImage(systemName: "photo.on.rectangle.angled")
        photo.contentMode = .scaleAspectFill
        photo.layer.cornerRadius = 75
        photo.clipsToBounds = true
        photo.tintColor = .systemGreen
        photo.layer.borderWidth = 5
        photo.layer.borderColor = UIColor.darkGray.cgColor
        
        view.addSubview(photo)
        photo.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(200)
            make.right.left.width.equalToSuperview().inset(20)
            make.height.equalTo(400)
        }
        let selectButton = UIButton()
        selectButton.setTitleColor(.blue, for: .normal)
        selectButton.addTarget(self, action: #selector(selectPhotoButtonTapped), for: .touchUpInside)
        view.addSubview(selectButton)
        selectButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(200)
            make.right.left.width.equalToSuperview().inset(20)
            make.height.equalTo(400)
        }
        let uploadButton = UIButton()
        uploadButton.setTitle("Upload", for: .normal)
        uploadButton.setTitleColor(.white, for: .normal)
        uploadButton.backgroundColor = .gray
        uploadButton.layer.cornerRadius = 20
        
        uploadButton.addTarget(self, action: #selector(uploadButtonTapped), for: .touchUpInside)
        view.addSubview(uploadButton)
        uploadButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(photo.snp.bottom).offset(20)
            make.right.left.width.equalToSuperview().inset(20)
            make.height.equalTo(50)
        }
    }
    
    @objc func selectPhotoButtonTapped() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    @objc func uploadButtonTapped() {
            guard let selectedImage = photo.image,
                  let imageData = selectedImage.jpegData(compressionQuality: 0.5) else {
                return
            }

            let uuid = UUID().uuidString
            let storageRef = Storage.storage().reference().child("Media/\(uuid).jpg")

            storageRef.putData(imageData, metadata: nil) { (metadata, error) in
                guard error == nil else {
                    print("Error uploading image: \(error!.localizedDescription)")
                    return
                }

                storageRef.downloadURL { (url, error) in
                    guard let downloadURL = url else {
                        print("Error getting download URL: \(error!.localizedDescription)")
                        return
                    }
                    print(downloadURL)
                    NotificationCenter.default.post(name: Notification.Name("DownloadURLNotification"), object: nil, userInfo: ["downloadURL": downloadURL])
                    
                }
                
            }
        }
    
}
extension UploadVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            photo.image = selectedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}
