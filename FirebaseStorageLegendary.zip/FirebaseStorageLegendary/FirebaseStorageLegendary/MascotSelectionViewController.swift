import UIKit
import SnapKit
import FirebaseStorage

class MascotSelectionViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    private var mascotImageView: UIImageView!
    private var uploadButton: UIButton!
    private var selectedImage: UIImage?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
        view.backgroundColor = .white
    }

    private func setupViews() {
        mascotImageView = UIImageView()
        mascotImageView.contentMode = .scaleAspectFit
        view.addSubview(mascotImageView)

        mascotImageView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(20)
            make.width.height.equalTo(200)
        }

        uploadButton = UIButton()
        uploadButton.setTitle("Upload", for: .normal)
        uploadButton.setTitleColor(.blue, for: .normal)
        uploadButton.addTarget(self, action: #selector(uploadButtonTapped), for: .touchUpInside)
        uploadButton.isHidden = true
        view.addSubview(uploadButton)

        uploadButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(mascotImageView.snp.bottom).offset(20)
        }
    }

    @objc private func uploadButtonTapped() {
        if let selectedImage = selectedImage {
            uploadMascotImage(image: selectedImage) { downloadURL in
                if let downloadURL = downloadURL {
                    DispatchQueue.main.async {
                        let destinationVC = DownloadScreenViewController()
                        destinationVC.downloadURL = downloadURL
                        self.present(destinationVC, animated: true, completion: nil)
                    }
                } else {
                    // Hata durumunu işle
                    print("Upload failed.")
                }
            }
        }
    }

    private func uploadMascotImage(image: UIImage, completion: @escaping (String?) -> Void) {
        let storageRef = Storage.storage().reference().child("mascotImages/\(UUID().uuidString).jpg")
        guard let imageData = image.jpegData(compressionQuality: 0.5) else {
            completion(nil)
            return
        }

        storageRef.putData(imageData, metadata: nil) { (_, error) in
            if let error = error {
                print("Error uploading image: \(error.localizedDescription)")
                completion(nil)
            } else {
                storageRef.downloadURL { (url, error) in
                    if let downloadURL = url?.absoluteString {
                        completion(downloadURL)
                    } else {
                        print("Error getting download URL: \(error?.localizedDescription ?? "Unknown error")")
                        completion(nil)
                    }
                }
            }
        }
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            mascotImageView.image = selectedImage
            uploadButton.isHidden = false
            self.selectedImage = selectedImage
        }
        picker.dismiss(animated: true, completion: nil)
    }
}
