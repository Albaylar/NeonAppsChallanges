//
//  TabBarViewController.swift
//  FirebaseStorageLegendary
//
//  Created by Furkan Deniz Albaylar on 20.11.2023.
//

import UIKit

class TabBarViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    func setupUI() {
        view.backgroundColor = .red
        let tabbar = UITabBarController()
        tabbar.tabBar.layer.cornerRadius = 30
        tabbar.tabBar.layer.opacity = 1
        tabbar.tabBar.backgroundColor = .darkGray
        tabbar.tabBar.tintColor = .white
        let feedVC = ViewController()
        let feedImage = UIImage(systemName: "photo")
        feedVC.tabBarItem = UITabBarItem(title: "Photo", image: feedImage, tag: 0)
        let uploadVC = UploadVC()
        let image = UIImage(systemName: "square.and.arrow.up.circle.fill")
        uploadVC.tabBarItem = UITabBarItem(title: "Upload", image: image, tag: 1)
        view.backgroundColor = .white
        let viewControllers = [feedVC, uploadVC]
        tabbar.viewControllers = viewControllers
        self.addChild(tabbar)
        self.view.addSubview(tabbar.view)
        tabbar.view.frame = self.view.frame
    }
}
