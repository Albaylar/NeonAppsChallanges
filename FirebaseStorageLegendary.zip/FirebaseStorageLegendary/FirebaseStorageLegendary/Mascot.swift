//
//  Mascot.swift
//  FirebaseStorageLegendary
//
//  Created by Furkan Deniz Albaylar on 21.11.2023.
//

import Foundation

struct Mascot {
    var downloadURL: String
    // You can add more properties if needed
}
