import UIKit

class DownloadScreenViewController: UIViewController {

    private var downloadURLLabel: UILabel!
    private var downloadButton: UIButton!

    var downloadURL: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
    }

    private func setupViews() {
        downloadURLLabel = UILabel()
        downloadURLLabel.textAlignment = .center
        downloadURLLabel.numberOfLines = 0
        view.addSubview(downloadURLLabel)

        downloadURLLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(20)
            make.leading.trailing.equalToSuperview().inset(20)
        }

        downloadButton = UIButton()
        downloadButton.setTitle("Download Mascot Photo", for: .normal)
        downloadButton.setTitleColor(.blue, for: .normal)
        downloadButton.addTarget(self, action: #selector(downloadButtonTapped), for: .touchUpInside)
        view.addSubview(downloadButton)

        downloadButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(downloadURLLabel.snp.bottom).offset(20)
        }

        if let downloadURL = downloadURL {
            downloadURLLabel.text = downloadURL
        }
    }

    @objc private func downloadButtonTapped() {
        if let downloadURL = downloadURL {
            downloadMascotImage(fromURL: downloadURL) { image in
                if let image = image {
                    UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
                    // Fotoğrafın kaydedildiğine dair kullanıcıya geri bildirim gösterilebilir.
                } else {
                    // Hata durumunu işle
                    print("Download failed.")
                }
            }
        }
    }

    private func downloadMascotImage(fromURL urlString: String, completion: @escaping (UIImage?) -> Void) {
        if let url = URL(string: urlString) {
            URLSession.shared.dataTask(with: url) { (data, _, error) in
                if let data = data, let image = UIImage(data: data) {
                    completion(image)
                } else {
                    print("Error downloading image: \(error?.localizedDescription ?? "Unknown error")")
                    completion(nil)
                }
            }.resume()
        }
    }
}
