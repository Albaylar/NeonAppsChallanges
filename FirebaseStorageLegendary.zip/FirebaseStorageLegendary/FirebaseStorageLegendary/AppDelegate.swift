//
//  AppDelegate.swift
//  FirebaseStorageLegendary
//
//  Created by Furkan Deniz Albaylar on 20.11.2023.
//

import UIKit
import SnapKit
import FirebaseCore


@main
class AppDelegate: UIResponder, UIApplicationDelegate {

var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        FirebaseApp.configure()
        window = UIWindow()
        window?.rootViewController = TabBarViewController()
        window?.makeKeyAndVisible()
        return true
    }

 


}

