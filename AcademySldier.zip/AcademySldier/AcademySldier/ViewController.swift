

import UIKit

class ViewController: UIViewController {
    let slider = UISlider()
    let imageView = UIImageView()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }

    func setupUI() {
        view.addSubview(slider)
        slider.maximumTrackTintColor = .green
        slider.minimumTrackTintColor = .red
        //slider.isContinuous = false
        
        slider.snp.makeConstraints { make in
            make.centerY.equalToSuperview().offset(50)
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(300)
            make.width.equalTo(200)
            make.height.equalTo(50)
        }

        view.addSubview(imageView)

        imageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(100)
            make.centerX.equalToSuperview()
            make.width.equalTo(300)
            make.height.equalTo(200)
        }

        slider.minimumValue = 0
        slider.maximumValue = 50
        
        slider.value = slider.minimumValue
        slider.thumbTintColor = .blue 

        slider.addTarget(self, action: #selector(sliderValueDidChange), for: .valueChanged)
        updateImageView()
    }

    @objc func sliderValueDidChange(_ sender: UISlider) {
        let roundedValue = round(sender.value)
        sender.value = roundedValue
        print(roundedValue)
        updateImageView()
    }

    func updateImageView() {
        if slider.value == 0 {
            let image1 = UIImage(named: "redDragon")
            imageView.image = image1
        } else if slider.value == 50 {
            let image2 = UIImage(named: "greenDragon")
            imageView.image = image2
        } else {
            imageView.image = nil
        }
        print(slider.value)
    }
}




