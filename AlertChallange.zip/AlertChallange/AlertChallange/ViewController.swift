//
//  ViewController.swift
//  AlertChallange
//
//  Created by Furkan Deniz Albaylar on 2.11.2023.
//

import UIKit

class ViewController: UIViewController {
    
    let alertButton = UIButton()
    let alertButton2 = UIButton()
    let alertButton3 = UIButton()
    let alertButton4 = UIButton()
    let alertButton5 = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setUpUI()
    }
    
    func setUpUI() {
        alertButton.setTitle("Alert", for: .normal)
        alertButton.backgroundColor = .red
        alertButton.addTarget(self, action: #selector(alertButtonClicked), for: .touchUpInside)
        
        alertButton2.setTitle("Alert with One Button", for: .normal)
        alertButton2.backgroundColor = .darkGray
        alertButton2.addTarget(self, action: #selector(alertButton2Clicked), for: .touchUpInside)
        
        alertButton3.setTitle("ActionSheet Alarm", for: .normal)
        alertButton3.backgroundColor = .systemBlue
        alertButton3.addTarget(self, action: #selector(alertButton3Clicked), for: .touchUpInside)
        
        alertButton4.setTitle("ActionSheet with TextField", for: .normal)
        alertButton4.backgroundColor = .green
        alertButton4.addTarget(self, action: #selector(alertButton4Clicked), for: .touchUpInside)
        
        alertButton5.setTitle("Show Activity Controller", for: .normal)
        alertButton5.backgroundColor = .orange
        alertButton5.addTarget(self, action: #selector(alertButton5Clicked), for: .touchUpInside)
        
        view.addSubview(alertButton)
        alertButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(200)
            make.width.equalTo(250)
        }
        
        view.addSubview(alertButton2)
        alertButton2.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(alertButton.snp.bottom).offset(50)
            make.width.equalTo(250)
        }
        
        view.addSubview(alertButton3)
        alertButton3.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(alertButton2.snp.bottom).offset(50)
            make.width.equalTo(250)
        }
        
        view.addSubview(alertButton4)
        alertButton4.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(alertButton3.snp.bottom).offset(50)
            make.width.equalTo(250)
        }
        
        view.addSubview(alertButton5)
        alertButton5.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(alertButton4.snp.bottom).offset(50)
            make.width.equalTo(250)
        }
    }
    
    @objc func alertButtonClicked() {
        let alert = UIAlertController(title: "This is an alert", message: "There is no escaping for you", preferredStyle: .alert)
        present(alert, animated: true, completion: nil)
    }
    
    @objc func alertButton2Clicked() {
        let alert = UIAlertController(title: "Alert with One Button", message: "Click a Button", preferredStyle: .alert)
        
        let OkButton = UIAlertAction(title: "OK", style: .default) { _ in
            print("OK button tapped")
        }
        
        alert.addAction(OkButton)
        present(alert, animated: true, completion: nil)
    }
    
    @objc func alertButton3Clicked() {
        let alert = UIAlertController(title: "ActionSheet Alarm", message: "Choose an option", preferredStyle: .actionSheet)
        
        let option1 = UIAlertAction(title: "Option 1", style: .default) { result in
            print("Option 1 selected")
        }
        
        let option2 = UIAlertAction(title: "Option 2", style: .default) { result in
            print("Option 2 selected")
        }
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel) { result in
            print("Action sheet canceled")
        }
        
        alert.addAction(option1)
        alert.addAction(option2)
        alert.addAction(cancel)
        
        present(alert, animated: true, completion: nil)
    }
    
    @objc func alertButton4Clicked() {
        let alert = UIAlertController(title: "Alert with TextField", message: "Enter Text", preferredStyle: .alert)
        
        alert.addTextField { textField in
            textField.placeholder = "Enter text"
        }
        
        let OkButton = UIAlertAction(title: "OK", style: .default) { _ in
            if let textField = alert.textFields?.first, let text = textField.text {
                print("Entered text: \(text)")
            }
        }
        
        alert.addAction(OkButton)
        present(alert, animated: true, completion: nil)
    }
    
    @objc func alertButton5Clicked() {
        let activityController = UIActivityViewController(activityItems: ["Hello, this is a test message","One more"], applicationActivities: nil)
        present(activityController, animated: true, completion: nil)
    }
}


