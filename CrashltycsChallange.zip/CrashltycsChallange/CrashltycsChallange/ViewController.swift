//
//  ViewController.swift
//  CrashltycsChallange
//
//  Created by Furkan Deniz Albaylar on 22.11.2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
    }
    func setupUI(){
        view.backgroundColor = .systemRed
        let button = UIButton()
        button.setTitle("Crash", for: .normal)
        button.backgroundColor = .systemBlue
        button.layer.cornerRadius = 20
        button.addTarget(self, action: #selector(buttonTapped), for: .touchUpInside)
        view.addSubview(button)
        button.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(200)
            make.right.left.width.equalToSuperview().inset(100)
            make.height.equalTo(50)
        }
    }
    @objc func buttonTapped(){
        let numbers = [0]
        let _ = numbers[1]
    }


}

