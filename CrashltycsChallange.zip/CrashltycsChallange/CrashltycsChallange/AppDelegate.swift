//
//  AppDelegate.swift
//  CrashltycsChallange
//
//  Created by Furkan Deniz Albaylar on 22.11.2023.
//

import UIKit
import Firebase
import SnapKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow()
        FirebaseApp.configure()
        window?.rootViewController = ViewController()
        window?.makeKeyAndVisible()
        return true
    }


}

