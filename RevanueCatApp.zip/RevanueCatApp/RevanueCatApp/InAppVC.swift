//
//  InAppVC.swift
//  RevanueCatApp
//
//  Created by Furkan Deniz Albaylar on 24.11.2023.
//

import UIKit
import RevenueCat
import SwiftUI

class InAppVC: UIViewController {
    var selectedPackage: Package?
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        fetchMonthlyPackage()
    }

    private func setupUI() {
        view.backgroundColor = .white
        
        
        let subscribeButton = UIButton()
        subscribeButton.setTitle("Subscribe", for: .normal)
        subscribeButton.setTitleColor(.white, for: .normal)
        subscribeButton.backgroundColor = .systemGreen
        subscribeButton.addTarget(self, action: #selector(subscribeButtonTapped), for: .touchUpInside)
        subscribeButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(subscribeButton)
        subscribeButton.snp.makeConstraints { make in
            make.centerX.centerY.equalToSuperview()
            make.width.equalToSuperview().multipliedBy(0.25)
        }
        let restoreButton = UIButton()
        restoreButton.setTitle("Restore Button", for: .normal)
        restoreButton.setTitleColor(.link, for: .normal)
        restoreButton.addTarget(self, action: #selector(restoreButtonTapped), for: .touchUpInside)
        restoreButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(restoreButton)
        restoreButton.snp.makeConstraints { make in
            make.top.equalTo(subscribeButton.snp.bottom).offset(20)
            make.centerX.equalToSuperview()
        }
    }

    func fetchMonthlyPackage() {
           Purchases.shared.getOfferings { [self] offerings, _ in
               guard let offerings = offerings, let currentOffering = offerings.current else {
                   print("Satın alma paketleri alınamadı.")
                   return
               }

               let monthlyPackageId = "com.neonapps.education.SwiftyStoreKitDemo.Monthly"
               if let monthlyPackage = currentOffering.availablePackages.first(where: { $0.storeProduct.productIdentifier == monthlyPackageId }) {
                   // İlgili işlemleri gerçekleştir
                   selectedPackage = monthlyPackage
                   print("Monthly Package ID: \(monthlyPackage.storeProduct.productIdentifier)")
                   print("Localized Price: \(monthlyPackage.localizedPriceString)")
                   // packages dizisine ekle
               } else {
                   print("Monthly Package bulunamadı.")
               }
           }
       }

    func purchase(package: Package, completion: @escaping (Bool) -> Void) {
            Purchases.shared.purchase(package: package) { (transaction, customerInfo, error, userCancelled) in
                if let error = error {
                    print("Satın alma hatası: \(error.localizedDescription)")
                    completion(false)
                    return
                }

                if let customerInfo = customerInfo, customerInfo.entitlements.all["Monthly"]?.isActive == true {
                    print("Satın alma başarılı. 'Montly' özelliği aktif.")
                    completion(true)
                } else {
                    print("Satın alma başarılı, ancak 'Montly' özelliği aktif değil.")
                    completion(false)
                }
            }
        }



    func restorePurchases(completion: @escaping (Bool) -> Void) {
        Purchases.shared.restorePurchases { [weak self] info, error in
            guard let self = self else {
                completion(false)
                return
            }

            if let error = error {
                print("Restore failed. Error: \(error.localizedDescription)")
                let alertController = UIAlertController(title: "Error", message: "Restore failed. \(error.localizedDescription)", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alertController, animated: true, completion: nil)

                completion(false)
                return
            }

            if info?.entitlements.all["Monthly"]?.isActive == true {
                print("Restore successful. 'Montly' entitlement is active.")
                let vc = MainVC()
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: true)

                completion(true)
            } else {
                print(error?.localizedDescription)
                // Kullanıcıya bilgi ver
                let alertController = UIAlertController(title: "Success", message: "Restore not successful, but 'Montly' entitlement is not active.", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alertController, animated: true, completion: nil)

                completion(false)
            }
        }
    }


    @objc private func subscribeButtonTapped() {
        purchase(package: selectedPackage!) { success in
                if success {
                    print("asd")
                    DispatchQueue.main.async {
                        let mainVC = MainVC()
                        mainVC.modalPresentationStyle = .fullScreen
                        self.present(mainVC, animated: true)
                    }
                } else {
                    print("qweqweq")
                }
            }
        }

    @objc private func restoreButtonTapped() {
        restorePurchases { success in
            if success {
                print("Restore işlemi başarıyla tamamlandı.")
                // İlgili işlemleri gerçekleştir, örneğin MainVC'ye geçiş yapabilirsin
                DispatchQueue.main.async {
                    let mainVC = MainVC()
                    mainVC.modalPresentationStyle = .fullScreen
                    self.present(mainVC, animated: true)
                }
            } else {
                print()
            }
        }
    }

}
#Preview(body: {
    InAppVC()
})


