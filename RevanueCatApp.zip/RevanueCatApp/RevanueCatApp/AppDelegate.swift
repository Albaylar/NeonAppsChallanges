//
//  AppDelegate.swift
//  RevanueCatApp
//
//  Created by Furkan Deniz Albaylar on 24.11.2023.
//

import UIKit
import RevenueCat


@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
      
     
        Purchases.configure(withAPIKey:"appl_sBMEJHbmOuyWjKLOeLuaTURYHPK")
        Purchases.logLevel = .debug
        Purchases.shared.delegate = self // make sure to set this after calling configure
        
        window = UIWindow()
        window?.rootViewController = InAppVC()
        window?.makeKeyAndVisible()
        
        
        return true
    }
}
    
extension AppDelegate: PurchasesDelegate {
        func purchases(_ purchases: Purchases, receivedUpdated customerInfo: CustomerInfo) {
            
        }
    }

