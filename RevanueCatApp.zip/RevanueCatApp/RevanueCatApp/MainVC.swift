//
//  ViewController.swift
//  RevenueCatApp
//
//  Created by Furkan Deniz Albaylar on 24.11.2023.
//

import UIKit
import SnapKit
import SwiftUI

class MainVC: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setupUI()
    }
    
    private func setupUI() {
        
        let label = UILabel()
        label.text = "You are subscribed"
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 32)
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        
        label.snp.makeConstraints { make in
            make.centerX.centerY.equalToSuperview()
            make.width.equalToSuperview()
        }
    }
}

#Preview(body: {
    MainVC()
})




