//
//  ViewController.swift
//  View Controller Color Wizard
//
//  Created by Furkan Deniz Albaylar on 1.11.2023.
//

import UIKit

class ViewController: UIViewController {
    
    let switch1 = UISwitch()
    var switchIsOn = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .green
        setupUI()
    }
    
    func setupUI(){
        view.addSubview(switch1)
        switch1.addTarget(self, action: #selector(switchStateChanged), for: .touchUpInside)
        
        
        
        switch1.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(100)
        }
        
        
    }
    @objc func switchStateChanged() {
        if switch1.isOn {
            view.backgroundColor = .green
            switchIsOn = true
            switch1.onTintColor = .red
            switch1.thumbTintColor = .black
        } else {
            view.backgroundColor = .red
            switchIsOn = false
            switch1.thumbTintColor = .black
        }
    }



}

