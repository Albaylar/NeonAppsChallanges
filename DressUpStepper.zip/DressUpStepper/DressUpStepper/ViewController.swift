import UIKit

class ViewController: UIViewController {
    let stepper = UIStepper()
    let dividerView = UIView()
    let valueLabel = UILabel()
    let incrementButton =  UIButton()
    let decrementButton = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }

    func setupUI() {
        // Stepper'ı ayarla
        view.addSubview(stepper)
        stepper.backgroundColor = .systemPink
        stepper.addTarget(self, action: #selector(stepperValueChanged), for: .valueChanged)
        stepper.maximumValue = 10 // Her yerde 5 le çarpılacağı için 10 yaptım 10 yapınca maximum 50 olacaktır.

        stepper.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(100)
            make.centerX.equalToSuperview()
            make.width.equalTo(100)
        }

        // Ayırıcıyı ayarla
        view.addSubview(dividerView)
        dividerView.backgroundColor = .blue

        dividerView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(stepper.snp.bottom).offset(70)
            make.width.equalTo(2)
            make.bottom.equalToSuperview().offset(-50)
        }

        // Plus - Minus Buttons
        view.addSubview(incrementButton)
        view.addSubview(decrementButton)
        incrementButton.setImage(UIImage(named: "increamentButton"), for: .normal)
        decrementButton.setImage(UIImage(named: "decreamentHeart"), for: .normal)

        incrementButton.addTarget(self, action: #selector(incrementButtonTapped), for: .touchUpInside)
        decrementButton.addTarget(self, action: #selector(decrementButtonTapped), for: .touchUpInside)
        // Butonların görünümünü ayarla
        incrementButton.snp.makeConstraints { make in
            make.centerY.equalTo(stepper)
            make.trailing.equalTo(stepper.snp.leading).offset(-20)
            make.width.height.equalTo(30)
        }

        decrementButton.snp.makeConstraints { make in
            make.centerY.equalTo(stepper)
            make.leading.equalTo(stepper.snp.trailing).offset(20)
            make.width.height.equalTo(30)
        }

        // Değer etiketini ayarla
        view.addSubview(valueLabel)
        valueLabel.textAlignment = .center
        valueLabel.text = "0"
        valueLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(stepper.snp.bottom).offset(30)
        }
    }

    @objc func stepperValueChanged() {
            let value = Int(stepper.value) * 5
            valueLabel.text = "\(Int(value))"
        }

        @objc func incrementButtonTapped() {
            stepper.value += 1
            valueLabel.text = "\(Int(stepper.value * 5))"
        }

        @objc func decrementButtonTapped() {
            stepper.value -= 1
            valueLabel.text = "\(Int(stepper.value * 5))"
        }
}
