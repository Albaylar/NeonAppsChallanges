//
//  ViewController.swift
//  TabBar
//
//  Created by Furkan Deniz Albaylar on 3.11.2023.
//

import UIKit

class ViewController: UIViewController {
    
    let tabbar = UITabBarController()
    let firstVC = UIViewController()
    let secondVC = UIViewController()
    let thirdVC = UIViewController()
    let fourthVC = UIViewController()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
    }
    func setupUI(){
        
        tabbar.tabBar.layer.cornerRadius = 30
        tabbar.tabBar.layer.opacity = 1
        firstVC.view.backgroundColor = .red
        firstVC.tabBarItem = UITabBarItem(tabBarSystemItem: .favorites, tag: 0) // Kullanmak istediğiniz sistem simgesini belirtin
        secondVC.view.backgroundColor = .blue
        secondVC.tabBarItem = UITabBarItem(tabBarSystemItem: .bookmarks, tag: 1) // Kullanmak istediğiniz sistem simgesini belirtin
        thirdVC.view.backgroundColor = .green
        thirdVC.tabBarItem = UITabBarItem(tabBarSystemItem: .contacts, tag: 2) // Kullanmak istediğiniz sistem simgesini belirtin
        fourthVC.view.backgroundColor = .black
        fourthVC.tabBarItem = UITabBarItem(tabBarSystemItem: .downloads, tag: 3) // Kullanmak istediğiniz sistem simgesini belirtin
        
        tabbar.tabBar.backgroundColor = .darkGray
        
        
        let viewControllers = [firstVC,secondVC,thirdVC,fourthVC]
        tabbar.viewControllers = viewControllers
        self.addChild(tabbar)
        self.view.addSubview(tabbar.view)
        tabbar.view.frame = self.view.frame
        
        
        
        
            
        
    }


}
extension ViewController : UITabBarControllerDelegate {
    
}

