//
//  DetailViewController.swift
//  TitanicChallenge
//
//  Created by Furkan Deniz Albaylar on 6.11.2023.
//

import UIKit
import SnapKit

class DetailViewController: UIViewController {
    var detailClosure: ((PassengerModel) -> Void)?
    var pass: [PassengerModel] = []
    let name = UILabel()
    let surname = UILabel()
    var backButton = UIButton()
    let email = UILabel()
    let team = UILabel()
    let age = UILabel()
    let homeTown = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .red
        
        name.text = ("Name : \(pass.first?.name ?? "") \(pass.first?.surname ?? "")")
        name.textColor = .black
        name.textAlignment = .center
        name.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        view.addSubview(name)
        name.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(100)
            make.width.equalTo(300)
            make.height.equalTo(100)

        }
        //surname.text = pass.first?.surname
        surname.textColor = .black
        surname.textAlignment = .center
        surname.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        view.addSubview(surname)
        
        
        //email.text = pass.first?.email
        email.text = ("Email : \(pass.first?.email ?? "")")
        view.addSubview(email)
        
        email.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(name).offset(100)
            make.width.equalTo(300)
            make.height.equalTo(100)
        }
       // team.text = pass.first?.team
        team.text = ("Team : \(pass.first?.team ?? "")")
        view.addSubview(team)
        
        team.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(email).offset(50)
            make.width.equalTo(300)
            make.height.equalTo(100)
        }
        age.text = "Age: \(String(pass.first?.age ?? 0))"

        view.addSubview(age)
        
        age.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(team).offset(50)
            make.width.equalTo(300)
            make.height.equalTo(100)
        }
        
        homeTown.text = "HomeTown : \(pass.first?.homeTown ?? "")"
        view.addSubview(homeTown)
        
        homeTown.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(age).offset(50)
            make.width.equalTo(300)
            make.height.equalTo(100)
        }

        backButton.setTitle("<Back", for: .normal)
        backButton.setTitleColor(.systemBlue, for: .normal)
        backButton.addTarget(self, action: #selector(goBack), for: .touchUpInside)
        view.addSubview(backButton)

        backButton.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(0)
            make.leading.equalToSuperview().offset(-13)
            make.width.equalTo(100)
            make.height.equalTo(40)
        }
    }
    
    @objc func goBack() {
        self.dismiss(animated: true, completion: nil)
    }
}
