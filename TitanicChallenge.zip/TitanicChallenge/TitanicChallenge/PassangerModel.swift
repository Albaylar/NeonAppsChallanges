//
//  PassangerModel.swift
//  TitanicChallenge
//
//  Created by Furkan Deniz Albaylar on 6.11.2023.
//

import Foundation

struct PassengerModel {
    let name: String
    let surname: String
    let team: String
    let age: Int
    let homeTown: String
    let email: String
}
