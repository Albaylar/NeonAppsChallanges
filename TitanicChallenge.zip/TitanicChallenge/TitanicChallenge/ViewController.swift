//
//  ViewController.swift
//  TitanicChallenge
//
//  Created by Furkan Deniz Albaylar on 6.11.2023.
//

import UIKit

class ViewController: UIViewController {
    
    let tableView = UITableView()
    //let teams = ["iOS Team","Android Team","Design Team"]
    //let teams = PassangerModel()
    
    var passengers: [PassengerModel] = [
        PassengerModel(name: "John", surname: "Doe", team: "iOS Team", age: 30, homeTown: "New York", email: "john.doe@example.com"),
        PassengerModel(name: "Jane", surname: "Smith", team: "Design Team", age: 25, homeTown: "San Francisco", email: "jane.smith@example.com"),
        PassengerModel(name: "Alice", surname: "Williams", team: "Android Team", age: 28, homeTown: "Chicago", email: "alice.williams@example.com"),
        PassengerModel(name: "Michael", surname: "Johnson", team: "iOS Team", age: 35, homeTown: "Los Angeles", email: "michael.johnson@example.com"),
        PassengerModel(name: "Emily", surname: "Jones", team: "Design Team", age: 27, homeTown: "Seattle", email: "emily.jones@example.com"),
        PassengerModel(name: "Robert", surname: "Brown", team: "iOS Team", age: 32, homeTown: "Houston", email: "robert.brown@example.com"),
        PassengerModel(name: "Emma", surname: "Garcia", team: "Design Team", age: 29, homeTown: "Miami", email: "emma.garcia@example.com"),
        PassengerModel(name: "William", surname: "Miller", team: "Android Team", age: 31, homeTown: "Phoenix", email: "william.miller@example.com"),
        PassengerModel(name: "Olivia", surname: "Martinez", team: "iOS Team", age: 33, homeTown: "Philadelphia", email: "olivia.martinez@example.com"),
       
    ]


    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }
    func setupUI(){
      //  let navigationController = UINavigationController(rootViewController: self)
       // navigationController.navigationBar.isTranslucent = false
        tableView.delegate = self
        tableView.dataSource = self
        view.addSubview(tableView)
        
        
        tableView.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide)
            make.leading.trailing.bottom.equalToSuperview()
        }
        
        
    }
}
extension ViewController : UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedItem = passengers[indexPath.row]
        
        let detailVC = DetailViewController()
       
        detailVC.pass = [selectedItem]
        detailVC.detailClosure = { [weak self] passenger in
        }
        
        detailVC.modalPresentationStyle = .fullScreen
        present(detailVC, animated: true)
    }
}
extension ViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return passengers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        let passenger = passengers[indexPath.row]
        cell.textLabel?.text = "\(passenger.name) \(passenger.surname)"
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let deleteAction = UITableViewRowAction(style: .destructive, title: "Delete") { action, index in
            self.passengers.remove(at: indexPath.row)
            tableView.reloadData()
        }
        return [deleteAction]
    }
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }

    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
            let moreAction = UIContextualAction(style: .normal, title: "More") { (action, view, completionHandler) in
                
                completionHandler(true)
            }
            let configuration = UISwipeActionsConfiguration(actions: [moreAction])
            return configuration // Burada önceden kaydırma için bir eylem yapılandırması döndürüyoruz.
        }
    
    
}

