//
//  Model.swift
//  RestfulApiChallange
//
//  Created by Furkan Deniz Albaylar on 23.11.2023.
//

import Foundation
