//
//  ViewController.swift
//  RestfulApiChallange
//
//  Created by Furkan Deniz Albaylar on 23.11.2023.
//

import UIKit

class ViewController: UIViewController {

    let tableView = UITableView()
    var data: [CharacterData] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        fetchData()
    }
    
    func setupUI() {
        view.backgroundColor = .white

        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(ListCell.self, forCellReuseIdentifier: "cell")

        view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview().offset(10)
        }
    }

    func fetchData() {
        Network.shared.fetchData { (data, error) in
            if let error = error {
                print("Error: \(error.localizedDescription)")
            } else if let data = data {
                self.data = data
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
        }

    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ListCell
        let character = data[indexPath.row]
        cell.configure(with: character)
        return cell
    }
}


