//
//  ViewController.swift
//  AddMobChallange
//
//  Created by Furkan Deniz Albaylar on 13.11.2023.
//

import GoogleMobileAds
import UIKit
import SnapKit // SnapKit kütüphanesini ekledik

class ViewController: UIViewController, GADFullScreenContentDelegate {

    var bannerView: GADBannerView!
    private var interstitial: GADInterstitialAd?

    override func viewDidLoad() {
        super.viewDidLoad()
        // UI bileşenlerini oluşturan fonksiyonu çağırın
        setupUI()
    }

    func addBannerViewToView(_ bannerView: GADBannerView) {
        bannerView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bannerView)
        bannerView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview()
            make.height.equalTo(50)
            make.width.equalTo(400)
        }
    }
    
    func setupUI() {
        view.backgroundColor = .systemRed
        let addMobButton = UIButton() // Değişken adını küçük harfle başlattık
        addMobButton.setTitle("Add Mob Button", for: .normal)
        addMobButton.layer.cornerRadius = 20
        addMobButton.backgroundColor = .systemBlue
        view.addSubview(addMobButton)
        addMobButton.addTarget(self, action: #selector(addMobButtonClicked), for: .touchUpInside)
        
        // SnapKit kütüphanesini kullanarak UI bileşenlerini düzenleme
        addMobButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(400)
            make.height.equalTo(50)
            make.width.equalTo(200)
        }
        let request = GADRequest()
            GADInterstitialAd.load(withAdUnitID: "ca-app-pub-3940256099942544/4411468910",
                                        request: request,
                              completionHandler: { [self] ad, error in
                                if let error = error {
                                  print("Failed to load interstitial ad with error: \(error.localizedDescription)")
                                  return
                                }
                                interstitial = ad
                                interstitial?.fullScreenContentDelegate = self
                              }
            )
        // BannerView'yi oluşturmadan önce reklam birim kimliğini belirtmelisiniz.
        bannerView = GADBannerView(adSize: GADAdSizeBanner)
        bannerView.adUnitID = "ca-app-pub-3940256099942544/2934735716"
        bannerView.rootViewController = self
        bannerView.load(GADRequest())

        addBannerViewToView(bannerView)
        
    }
    func ad(_ ad: GADFullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: Error) {
        print("Ad did fail to present full screen content.")
      }

      /// Tells the delegate that the ad will present full screen content.
      func adWillPresentFullScreenContent(_ ad: GADFullScreenPresentingAd) {
        print("Ad will present full screen content.")
      }

      /// Tells the delegate that the ad dismissed full screen content.
      func adDidDismissFullScreenContent(_ ad: GADFullScreenPresentingAd) {
          let detailViewController = DetailViewController()
          detailViewController.modalPresentationStyle = .fullScreen
          present(detailViewController, animated: true)
        print("Ad did dismiss full screen content.")
      }
    @objc func addMobButtonClicked(){
        if interstitial != nil {
            interstitial?.present(fromRootViewController: self)
            
          } else {
            print("Ad wasn't ready")
          }
    }
}

    
    




