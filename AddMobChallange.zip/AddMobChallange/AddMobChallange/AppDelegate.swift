//
//  AppDelegate.swift
//  AddMobChallange
//
//  Created by Furkan Deniz Albaylar on 13.11.2023.
//

import UIKit
import SnapKit
import GoogleMobileAds

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow()
        window?.rootViewController = ViewController()
        window?.makeKeyAndVisible()
        GADMobileAds.sharedInstance().start(completionHandler: nil)
        //ca-app-pub-9645439906826429/4485520439
        return true
    }



}

