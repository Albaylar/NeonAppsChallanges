//
//  DetailViewController.swift
//  AddMobChallange
//
//  Created by Furkan Deniz Albaylar on 13.11.2023.
//

import UIKit
import GoogleMobileAds


class DetailViewController: UIViewController {
    private var rewardedInterstitialAd: GADRewardedInterstitialAd?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()

        
    }
    func setupUI(){
        view.backgroundColor = .white
        let backButton = UIButton()
        backButton.setTitle("< Back", for: .normal)
        backButton.layer.cornerRadius = 10
        backButton.backgroundColor = .lightGray
        
        view.addSubview(backButton)
        backButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)
        backButton.snp.makeConstraints { make in
              make.top.equalToSuperview().offset(50)
              make.leading.equalToSuperview().offset(20)
            }
        let rewardbutton = UIButton()
        rewardbutton.setTitle("Reward Button", for: .normal)
        rewardbutton.backgroundColor = .green
        rewardbutton.layer.cornerRadius = 20
        
        view.addSubview(rewardbutton)
        rewardbutton.addTarget(self, action: #selector(rewardedButtonClicked), for: .touchUpInside)
        rewardbutton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(200)
            make.centerX.equalToSuperview()
            make.right.left.width.equalToSuperview().inset(100)
            make.height.equalTo(50)
        }
        GADRewardedInterstitialAd.load(withAdUnitID:"ca-app-pub-3940256099942544/6978759866",
            request: GADRequest()) { ad, error in
            if error != nil {
                  let options = GADServerSideVerificationOptions()
                        options.customRewardString = "SAMPLE_CUSTOM_DATA_STRING"
                  self.rewardedInterstitialAd?.serverSideVerificationOptions = options
                
              }

              self.rewardedInterstitialAd = ad
              self.rewardedInterstitialAd?.fullScreenContentDelegate = self
            
            }
    }
    
    @objc func backButtonTapped() {
        self.dismiss(animated: true, completion: nil)
        print("Clicked")
      }
    @objc func rewardedButtonClicked(){
        guard let rewardedInterstitialAd = rewardedInterstitialAd else {
            return print("Ad wasn't ready.")
          }

          rewardedInterstitialAd.present(fromRootViewController: self) {
            let reward = rewardedInterstitialAd.adReward
            // TODO: Reward the user!
          }
    }
    

}
extension DetailViewController: GADFullScreenContentDelegate {

  /// Tells the delegate that the ad failed to present full screen content.
  func ad(_ ad: GADFullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: Error) {
    print("Ad did fail to present full screen content.")
  }

  /// Tells the delegate that the ad will present full screen content.
  func adWillPresentFullScreenContent(_ ad: GADFullScreenPresentingAd) {
    print("Ad will present full screen content.")
  }

  /// Tells the delegate that the ad dismissed full screen content.
  func adDidDismissFullScreenContent(_ ad: GADFullScreenPresentingAd) {
      let detailViewController = PremiumViewController()
      detailViewController.modalPresentationStyle = .fullScreen
      present(detailViewController, animated: true)
    print("Ad did dismiss full screen content.")
  }
}
