//
//  DetailViewController.swift
//  Top Secret Decryptio
//
//  Created by Furkan Deniz Albaylar on 31.10.2023.
//

import SnapKit
import UIKit

class DetailViewController: UIViewController {
    var myTextField = UITextField()
    var myButton = UIButton()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        
        
    }
    
    func setupUI(){
        myTextField.borderStyle = .line
        view.addSubview(myTextField)
        myTextField.snp.makeConstraints { make in
            make.left.right.equalToSuperview().inset(30)
            make.top.equalToSuperview().offset(100)
            make.height.equalTo(50)
        }
        myButton.setTitle("Ok", for: .normal)
        myButton.backgroundColor = .green
        myButton.addTarget(self, action: #selector(myButtonTapped), for: .touchUpInside)
        view.addSubview(myButton)
        myButton.snp.makeConstraints { make in
            make.top.equalTo(myTextField.snp.bottom).offset(20)
            make.centerX.equalToSuperview()
            make.height.width.equalTo(60)
        }
        
        
        
        
    }
    @objc func myButtonTapped(){
        
        NotificationCenter.default.post(name: Notification.Name("CustomNotification"), object: nil)
        dismiss(animated: true)
    }
}
