//
//  ViewController.swift
//  Top Secret Decryptio
//
//  Created by Furkan Deniz Albaylar on 27.10.2023.


import UIKit
import SnapKit

class ViewController: UIViewController {
    var myButton = UIButton()
    var myLabel = UILabel()
    var timer : Timer?
    var password = "123"
    var count = 15
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(notificationButtonTapped), name: Notification.Name("CustomNotification"), object: nil)
        view.backgroundColor = .white
        setupUI()
    }
    
    func setupUI(){
        myButton.setTitle("Next", for: .normal)
        myButton.backgroundColor = .blue
        myButton.addTarget(self, action: #selector(myButtonTapped), for: .touchUpInside)
        myButton.layer.cornerRadius = 15
        view.addSubview(myButton)
        myButton.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.height.equalTo(60)
        }
        
        view.addSubview(myLabel)
        myLabel.text = "test"
        myLabel.textColor = .red
        myLabel.snp.makeConstraints { make in
            make.bottom.equalTo(myButton.snp.top).offset(-30)
            make.centerX.equalToSuperview()
        }
        
        
    }
    @objc func myButtonTapped() {
        timer?.invalidate()
        count = 15
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
    }
    
    @objc func updateCounter() {
        
        if count > 0 {
            myLabel.text = "\(count)"
            count -= 1
        } else {
            timer?.invalidate()
            let destVC = DetailViewController()
            destVC.modalPresentationStyle = .fullScreen
            present(destVC, animated: true)
        }
    }
    
    
    @objc func notificationButtonTapped() {
        if let labelText = myLabel.text {
            if labelText == password {
                myLabel.text = "Şifre çözüldü..."
            }
        } else {
            let alert = UIAlertController(title: "Hata", message: "Geçersiz değer", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Tamam", style: .default, handler: nil)
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
        }
    }
}
   



