//
//  ViewController.swift
//  SeachBarChallange
//
//  Created by Furkan Deniz Albaylar on 6.11.2023.
//

import UIKit

class ViewController: UIViewController {
    
    let tableView = UITableView()
    let searchBar = UISearchBar()
    let segmentedControl = UISegmentedControl(items: ["Name","Surname"])
    var people: [Person] = [
        Person(name: "Mini", surname: "Mouse", description: "A kind and adventurous mouse"),
        Person(name: "mickey", surname: "Mouse", description: "A brave and clever mouse")
    ]
    var filteredPeople : [Person] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .darkGray
        filteredPeople = people
        setupUI()
    }
    
    func setupUI() {
        view.addSubview(searchBar)
        searchBar.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.width.equalToSuperview()
        }
        searchBar.showsScopeBar = true
        searchBar.delegate = self
        searchBar.tintColor = .darkGray
        searchBar.layer.cornerRadius = 10
        searchBar.clipsToBounds = true

        view.addSubview(segmentedControl)
        segmentedControl.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(searchBar.snp.bottom).offset(10)
            make.width.equalToSuperview().multipliedBy(1)
        }
        tableView.delegate = self
        tableView.dataSource = self
        view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.top.equalTo(segmentedControl.snp.bottom).offset(10)
            make.leading.equalTo(view.safeAreaLayoutGuide).offset(20)
            make.trailing.equalTo(view.safeAreaLayoutGuide).offset(-20)
            make.bottom.equalTo(view.safeAreaLayoutGuide)
        }
        
        tableView.layer.cornerRadius = 20
        tableView.clipsToBounds = true


        
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredPeople.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        let person = filteredPeople[indexPath.row]
        cell.textLabel?.text = "\(person.name) \(person.surname)"
        cell.detailTextLabel?.text = person.description
        return cell
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let moreAction = UIContextualAction(style: .normal, title: "More") { (action, view, completionHandler) in
            
            completionHandler(true)
        }
        let configuration = UISwipeActionsConfiguration(actions: [moreAction])
        return configuration
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            filteredPeople.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
}
extension ViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            filteredPeople = people
        } else {
            let scope = searchBar.selectedScopeButtonIndex
            if scope == 0 {
                filteredPeople = people.filter { person in
                    return person.name.lowercased().contains(searchText.lowercased())
                }
            } else {
                filteredPeople = people.filter { person in
                    return person.surname.lowercased().contains(searchText.lowercased())
                }
            }
        }
        tableView.reloadData()
    }
}






