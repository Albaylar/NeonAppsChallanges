//
//  Person.swift
//  SeachBarChallange
//
//  Created by Furkan Deniz Albaylar on 7.11.2023.
//

import Foundation

struct Person {
    var name: String
    var surname: String
    var description: String
}
