//
//  ViewController.swift
//  Animations
//
//  Created by Furkan Deniz Albaylar on 23.11.2023.
//

import UIKit
import SnapKit

class ViewController: UIViewController {
    let shortView = UIView()
    let imageView = UIImageView()
    var shortViewWidthConstraint: Constraint?
    var shortViewHeightConstraint: Constraint?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    func setupUI(){
        view.backgroundColor = .white
        
        shortView.backgroundColor = .systemCyan
        view.addSubview(shortView)
        shortView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(70)
            make.centerX.equalToSuperview()
            make.width.height.equalTo(100)
        }
        let hideButton = UIButton()
        hideButton.setTitle("Hide", for: .normal)
        hideButton.backgroundColor = .systemOrange
        hideButton.layer.cornerRadius = 20
        view.addSubview(hideButton)
        hideButton.addTarget(self, action: #selector(hideButtonTapped), for: .touchUpInside)
        hideButton.snp.makeConstraints { make in
            make.top.equalTo(shortView.snp.bottom).offset(20)
            make.centerX.equalToSuperview().offset(-50)
            make.height.width.equalTo(80)
        }
        let showButton = UIButton()
        showButton.setTitle("Show", for: .normal)
        showButton.backgroundColor = .systemOrange
        showButton.layer.cornerRadius = 20
        view.addSubview(showButton)
        showButton.setTitle("Show", for: .normal)
        showButton.addTarget(self, action: #selector(showButtonTapped), for: .touchUpInside)
        showButton.snp.makeConstraints { make in
            make.top.equalTo(shortView.snp.bottom).offset(20)
            make.centerX.equalToSuperview().offset(50)
            make.height.width.equalTo(80)
        }
        imageView.image = UIImage(named: "weapon1")
        imageView.layer.cornerRadius = 20
        view.addSubview(imageView)
        imageView.snp.makeConstraints { make in
            make.top.equalTo(showButton.snp.bottom).offset(50)
            make.centerX.equalToSuperview()
            make.right.left.width.equalToSuperview().inset(50)
            make.height.equalTo(150)
        }
        let turnRightButton = UIButton()
        turnRightButton.setTitle("Right", for: .normal)
        turnRightButton.backgroundColor = .systemRed
        turnRightButton.layer.cornerRadius = 20
        view.addSubview(turnRightButton)
        turnRightButton.addTarget(self, action: #selector(rightButtonTapped), for: .touchUpInside)
        turnRightButton.snp.makeConstraints { make in
            make.top.equalTo(imageView.snp.bottom).offset(80)
            make.centerX.equalToSuperview().offset(50)
            make.height.width.equalTo(60)
        }
        let turnleftButton = UIButton()
        turnleftButton.setTitle("Left", for: .normal)
        turnleftButton.backgroundColor = .systemRed
        turnleftButton.layer.cornerRadius = 20
        view.addSubview(turnleftButton)
        turnleftButton.addTarget(self, action: #selector(leftButtonTapped), for: .touchUpInside)
        turnleftButton.snp.makeConstraints { make in
            make.top.equalTo(imageView.snp.bottom).offset(80)
            make.centerX.equalToSuperview().offset(-50)
            make.height.width.equalTo(60)
        }
        let moveUpButton = UIButton()
        moveUpButton.setTitle("Up", for: .normal)
        moveUpButton.backgroundColor = .systemGray
        moveUpButton.layer.cornerRadius = 20
        view.addSubview(moveUpButton)
        moveUpButton.addTarget(self, action: #selector(moveUpButtonTapped), for: .touchUpInside)
        moveUpButton.snp.makeConstraints { make in
            make.top.equalTo(turnleftButton.snp.bottom).offset(20)
            make.centerX.equalToSuperview().offset(-50)
            make.height.width.equalTo(60)
        }
        let moveDownButton = UIButton()
        moveDownButton.setTitle("Down", for: .normal)
        moveDownButton.backgroundColor = .systemGray
        moveDownButton.layer.cornerRadius = 20
        view.addSubview(moveDownButton)
        moveDownButton.addTarget(self, action: #selector(moveDownButtonTapped), for: .touchUpInside)
        moveDownButton.snp.makeConstraints { make in
            make.top.equalTo(turnleftButton.snp.bottom).offset(20)
            make.centerX.equalToSuperview().offset(50)
            make.height.width.equalTo(60)
        }
        let growButton = UIButton()
        growButton.setTitle("Grow", for: .normal)
        growButton.backgroundColor = .systemBlue
        growButton.layer.cornerRadius = 20
        view.addSubview(growButton)
        growButton.addTarget(self, action: #selector(growButtonTapped), for: .touchUpInside)
        growButton.snp.makeConstraints { make in
            make.top.equalTo(moveUpButton.snp.bottom).offset(20)
            make.centerX.equalToSuperview().offset(-50)
            make.height.width.equalTo(60)
        }
        let shrinkButton = UIButton()
        shrinkButton.setTitle("Shrink", for: .normal)
        shrinkButton.backgroundColor = .systemBlue
        shrinkButton.layer.cornerRadius = 20
        view.addSubview(shrinkButton)
        shrinkButton.addTarget(self, action: #selector(shrinkButtonTapped), for: .touchUpInside)
        shrinkButton.snp.makeConstraints { make in
            make.top.equalTo(moveUpButton.snp.bottom).offset(20)
            make.centerX.equalToSuperview().offset(50)
            make.height.width.equalTo(60)
        }
    }
    @objc func hideButtonTapped() {
        UIView.animate(withDuration: 0.3) {
            self.shortView.alpha = 0.0
        }
    }
    @objc func showButtonTapped() {
        UIView.animate(withDuration: 0.3) {
            self.shortView.alpha = 1.0
        }
    }
    @objc func rightButtonTapped() {
        UIView.animate(withDuration: 0.3) {
            self.imageView.transform = self.imageView.transform.rotated(by: .pi/2)
        }
    }
    @objc func leftButtonTapped() {
        UIView.animate(withDuration: 0.3) {
            self.imageView.transform = self.imageView.transform.rotated(by: -.pi/2)
        }
    }
    @objc func moveUpButtonTapped() {
        UIView.animate(withDuration: 0.3) {
            self.shortView.snp.updateConstraints { make in
                make.top.equalToSuperview().offset(50)
            }
            self.view.layoutIfNeeded()
        }
    }
    @objc func moveDownButtonTapped() {
        UIView.animate(withDuration: 0.3) {
            self.shortView.snp.updateConstraints { make in
                make.top.equalToSuperview().offset(200)
            }
            self.view.layoutIfNeeded()
        }
    }
    @objc func growButtonTapped() {
        UIView.animate(withDuration: 0.3) {
            self.shortView.snp.updateConstraints { make in
                make.width.equalTo(200)
                make.height.equalTo(200)
            }
            self.view.layoutIfNeeded()
        }
    }
    @objc func shrinkButtonTapped() {
        UIView.animate(withDuration: 0.3) {
            self.shortView.snp.updateConstraints { make in
                make.width.equalTo(100)
                make.height.equalTo(100)
            }
            self.view.layoutIfNeeded()
        }
    }
}

