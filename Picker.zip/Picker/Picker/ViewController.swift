//
//  ViewController.swift
//  Picker
//
//  Created by Furkan Deniz Albaylar on 3.11.2023.
//

import UIKit

class ViewController: UIViewController {
    
    let picker = UIPickerView()
    let photo = UIImageView()
    let name = UILabel()
    let age = UILabel()
    let selectPhotoButton = UIButton()
    let changeFontButton = UIButton()
    let selectAgeButton = UIButton()
    let stackView = UIStackView()
    let colorPicker = UIColorPickerViewController()
    let colorChangeButton = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }
    func setupUI() {
        photo.image = UIImage(named: "FDA")
        photo.contentMode = .scaleAspectFill
        photo.layer.cornerRadius = 75
        photo.clipsToBounds = true
        photo.tintColor = .blue
        photo.layer.borderWidth = 5
        photo.layer.borderColor = UIColor.black.cgColor

        view.addSubview(photo)
        photo.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(200)
            make.height.width.equalTo(150)
        }

        name.text = "Furkan Deniz Albaylar"
        name.textColor = .black
        name.font = UIFont.boldSystemFont(ofSize: 20)
        view.addSubview(name)
        name.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(photo.snp.bottom).offset(20)
        }

        age.text = "Age: 26"
        age.textColor = .black
        age.font = UIFont.boldSystemFont(ofSize: 18)
        view.addSubview(age)
        age.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(name.snp.bottom).offset(20)
        }

        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.spacing = 10
        view.addSubview(stackView)
        stackView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(150)
        }
        stackView.addArrangedSubview(photo)
        stackView.addArrangedSubview(name)
        stackView.addArrangedSubview(age)
        stackView.addArrangedSubview(selectAgeButton)
        stackView.addArrangedSubview(selectPhotoButton)
        stackView.addArrangedSubview(colorChangeButton)

        selectAgeButton.setTitle("Change age", for: .normal)
        selectAgeButton.setTitleColor(.blue, for: .normal)
        selectAgeButton.addTarget(self, action: #selector(selectAgeButtonTapped), for: .touchUpInside)
        selectAgeButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(age.snp.bottom).offset(20)
            
           
        }

        changeFontButton.setTitle("Change Font", for: .normal)
        changeFontButton.setTitleColor(.blue, for: .normal)
        changeFontButton.addTarget(self, action: #selector(changeFontButtonTapped), for: .touchUpInside)
        view.addSubview(changeFontButton)
        changeFontButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(selectAgeButton.snp.bottom).offset(20)
            
        }

        selectPhotoButton.setTitleColor(.blue, for: .normal)
        selectPhotoButton.addTarget(self, action: #selector(selectPhotoButtonTapped), for: .touchUpInside)
        view.addSubview(selectPhotoButton)
        selectPhotoButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(200)
            make.height.width.equalTo(150)
        }
        
        
        colorChangeButton.setTitle("Color Change", for: .normal)
        colorChangeButton.setTitleColor(.blue, for: .normal)
        colorChangeButton.addTarget(self, action: #selector(colorChangeButtonTapped), for: .touchUpInside)
        view.addSubview(colorChangeButton)
        colorChangeButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(changeFontButton.snp.bottom).offset(20)
            make.height.equalTo(40)
        }
        
        
        
    }
    // Functions
    @objc func colorChangeButtonTapped(){
        colorPicker.delegate = self
        present(colorPicker, animated: true, completion: nil)
    }
    @objc func selectPhotoButtonTapped() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    @objc func changeFontButtonTapped() {
        let fontPickerViewController = UIFontPickerViewController()
        fontPickerViewController.delegate = self
        present(fontPickerViewController, animated: true, completion: nil)
    }
    func calculateAge(from date: Date) -> Int {
        let now = Date()
        let calendar = Calendar.current

        let ageComponents = calendar.dateComponents([.year], from: date, to: now)
        guard let age = ageComponents.year else { return 0 }

        return age
    }

    
    @objc func selectAgeButtonTapped() {
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        datePicker.preferredDatePickerStyle = .wheels

        let alert = UIAlertController(title: "Select your age", message: "\n\n\n\n\n\n\n\n", preferredStyle: .alert)
        alert.view.addSubview(datePicker)

        let selectAction = UIAlertAction(title: "Select", style: .default) { _ in
            let selectedDate = datePicker.date
            let age = self.calculateAge(from: selectedDate)
            self.age.text = "Age: \(age)"
        }

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)

        alert.addAction(selectAction)
        alert.addAction(cancelAction)

        present(alert, animated: true, completion: nil)
    }

}
extension ViewController : UIImagePickerControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let selectedImage = info[.originalImage] as? UIImage {
                photo.image = selectedImage
            }
            dismiss(animated: true, completion: nil)
        }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            dismiss(animated: true, completion: nil)
        }
    
}
extension ViewController : UINavigationControllerDelegate {
    
}
    
extension ViewController : UIFontPickerViewControllerDelegate {
    func fontPickerViewControllerDidPickFont(_ viewController: UIFontPickerViewController) {
        guard let descriptor = viewController.selectedFontDescriptor else { return }

            let font = UIFont(descriptor: descriptor, size: 36)
            name.font = font
            age.font = font
    }
    func fontPickerViewControllerDidCancel(_ viewController: UIFontPickerViewController) {
        
    }
}
extension ViewController : UIColorPickerViewControllerDelegate {
    func colorPickerViewControllerDidSelectColor(_ viewController: UIColorPickerViewController) {
        view.backgroundColor = viewController.selectedColor
    }
}
