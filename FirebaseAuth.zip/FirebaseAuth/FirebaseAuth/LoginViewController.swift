//
//  LoginViewController.swift
//  FirebaseAuthApp
//
//  Created by Furkan Deniz Albaylar on 14.11.2023.
//

import UIKit
import FirebaseAuth

class LoginViewController: UIViewController {
    
    let viewController = ViewController()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
    }
    func setupUI(){
        view.backgroundColor = .white
        
        let backButton = UIButton()
        backButton.setTitle("<Back", for: .normal)
        backButton.setTitleColor(.systemBlue, for: .normal)
        backButton.addTarget(self, action: #selector(goBack), for: .touchUpInside)
        view.addSubview(backButton)

        backButton.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(5)
            make.leading.equalToSuperview().offset(-13)
            make.width.equalTo(100)
            make.height.equalTo(40)
        }
        
        
        viewController.emailTextField.placeholder = "Please Enter a email"
        viewController.emailTextField.borderStyle = .roundedRect
        viewController.emailTextField.layer.cornerRadius = 100
        viewController.emailTextField.keyboardType = .emailAddress
        viewController.emailTextField.autocapitalizationType = .none


        view.addSubview(viewController.emailTextField)
        viewController.emailTextField.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(200)
            make.centerX.equalToSuperview()
            make.right.left.width.equalToSuperview().inset(50)
            make.height.equalTo(50)
        }
        
        viewController.passwordTextField.placeholder = "Please Enter a password"
        viewController.passwordTextField.borderStyle = .roundedRect
        viewController.passwordTextField.layer.cornerRadius = 100
        viewController.passwordTextField.isSecureTextEntry = true

        view.addSubview(viewController.passwordTextField)
        viewController.passwordTextField.snp.makeConstraints { make in
            make.top.equalTo(viewController.emailTextField.snp.bottom).offset(10)
            make.centerX.equalToSuperview()
            make.right.left.width.equalToSuperview().inset(50)
            make.height.equalTo(50)
        }
        let logInButton = UIButton()
        logInButton.setTitle("Sign In", for: .normal)
        logInButton.backgroundColor = .systemGreen
        logInButton.layer.cornerRadius = 20
        view.addSubview(logInButton)
        logInButton.addTarget(self, action: #selector(logInButtonClicked), for: .touchUpInside)
        logInButton.snp.makeConstraints { make in
            make.top.equalTo(viewController.passwordTextField.snp.bottom).offset(20)
            make.centerX.equalToSuperview()
            make.right.left.width.equalToSuperview().inset(70)
            make.height.equalTo(50)
        }
        let forgetPasswordButton = UIButton()
        forgetPasswordButton.setTitle("Forget Password", for: .normal)
        forgetPasswordButton.setTitleColor(.systemBlue, for: .normal)
        forgetPasswordButton.backgroundColor = .clear
        forgetPasswordButton.addTarget(self, action: #selector(forgetPasswordButtonClicked), for: .touchUpInside)
        view.addSubview(forgetPasswordButton)
        forgetPasswordButton.snp.makeConstraints { make in
            make.top.equalTo(logInButton.snp.bottom).offset(10)
            make.centerX.equalToSuperview()
            make.right.left.width.equalToSuperview().inset(70)
            make.height.equalTo(50)
        }
        let newAccountButton = UIButton()
        newAccountButton.setTitle("Sign up with new account", for: .normal)
        newAccountButton.setTitleColor(.systemBlue, for: .normal)
        newAccountButton.backgroundColor = .clear
        newAccountButton.addTarget(self, action: #selector(newAccountButtonClicked), for: .touchUpInside)
        view.addSubview(newAccountButton)
        newAccountButton.snp.makeConstraints { make in
            make.top.equalTo(forgetPasswordButton.snp.bottom).offset(10)
            make.centerX.equalToSuperview()
            make.right.left.width.equalToSuperview().inset(70)
            make.height.equalTo(50)
        }
        
        
    }
    @objc func logInButtonClicked() {
        Auth.auth().signIn(withEmail: viewController.emailTextField.text ?? "", password: viewController.passwordTextField.text ?? "") { [weak self] authResult, error in
            guard let strongSelf = self else { return }

            if let error = error {
                let alert = UIAlertController(title: "Alert", message: "Şifre veya email adresi hatalı.", preferredStyle: .alert)
                let okButton = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(okButton)
                self?.present(alert, animated: true, completion: nil)

                print("Error signing in: \(error.localizedDescription)")

                return
            }

            // Check if the user's email is verified
            if Auth.auth().currentUser?.isEmailVerified ?? false {
                // User is verified, proceed to DetailViewController
                let detailVC = DetailViewController()
                strongSelf.present(detailVC, animated: true)
            } else {
                // User's email is not verified, show an alert or take appropriate action
                let alert = UIAlertController(title: "Alert", message: "Please verify your email before proceeding.", preferredStyle: .alert)
                let okButton = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(okButton)
                strongSelf.present(alert, animated: true, completion: nil)
            }
        }
    }

    @objc func goBack(){
        self.dismiss(animated: true)
    }
    @objc func forgetPasswordButtonClicked() {
        let alert = UIAlertController(title: "Forgot Password", message: "Enter your email address to reset your password", preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.placeholder = "Email"
            textField.keyboardType = .emailAddress
        }
        
        let resetAction = UIAlertAction(title: "Reset Password", style: .default) { [weak self] (_) in
            guard let emailTextField = alert.textFields?.first, let email = emailTextField.text else {
                return
            }
            
            Auth.auth().sendPasswordReset(withEmail: email) { (error) in
                if let error = error {
                    let errorAlert = UIAlertController(title: "Error", message: "Error sending password reset email: \(error.localizedDescription)", preferredStyle: .alert)
                    let okButton = UIAlertAction(title: "OK", style: .default, handler: nil)
                    errorAlert.addAction(okButton)
                    self?.present(errorAlert, animated: true, completion: nil)
                } else {
                    let successAlert = UIAlertController(title: "Password Reset", message: "Password reset email sent successfully. Check your email for further instructions.", preferredStyle: .alert)
                    let okButton = UIAlertAction(title: "OK", style: .default, handler: nil)
                    successAlert.addAction(okButton)
                    self?.present(successAlert, animated: true, completion: nil)
                }
            }
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alert.addAction(resetAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }

    @objc func newAccountButtonClicked(){
        self.dismiss(animated: true)
//        let viewController = ViewController()
//        present(viewController, animated: true)
    }
}
