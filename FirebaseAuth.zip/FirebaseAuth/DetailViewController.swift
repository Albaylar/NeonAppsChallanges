//
//  DetailViewController.swift
//  FirebaseAuthApp
//
//  Created by Furkan Deniz Albaylar on 14.11.2023.
//

import UIKit

class DetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
    }
    func setupUI() {
        view.backgroundColor = .white
        
        let entryLabel = UILabel()
        entryLabel.text = "LOGIN PROCESS HAS BEEN DONE."
        entryLabel.textAlignment = .center
        entryLabel.textColor = .systemRed
        entryLabel.font = UIFont.boldSystemFont(ofSize: 20)
        
        view.addSubview(entryLabel)
        
        entryLabel.snp.makeConstraints { make in
            make.centerX.centerY.equalToSuperview() // Center the label
            make.left.right.width.equalToSuperview().inset(50)
            make.height.equalTo(100)
        }
    }
    
    
    
    

}
