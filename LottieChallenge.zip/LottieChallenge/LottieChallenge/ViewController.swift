//
//  ViewController.swift
//  LottieChallenge
//
//  Created by Furkan Deniz Albaylar on 8.11.2023.
//

import UIKit
import SnapKit
import Lottie

class ViewController: UIViewController {
    
    let animationView = LottieAnimationView()
    var animationTimer: Timer?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupAnimation()
        startAnimation()
    }

    func setupAnimation() {
        animationView.animation = LottieAnimation.named("animation") // Replace with your animation name
        animationView.contentMode = .scaleAspectFit
        animationView.loopMode = .loop // Set to play once
        animationView.animationSpeed = 0.4
        view.addSubview(animationView)
        animationView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().inset(300)
            make.width.height.equalTo(200)
        }

        let button = UIButton()
        button.setTitle("Go to Second VC", for: .normal)
        button.addTarget(self, action: #selector(transitionToDetailViewController), for: .touchUpInside)
        view.addSubview(button)
        button.backgroundColor = .systemGreen
        button.layer.cornerRadius = 20
        button.snp.makeConstraints { make in
            make.top.equalTo(animationView.snp.bottom).offset(50)
            make.centerX.equalToSuperview()
            make.width.equalTo(150)
            make.height.equalTo(50)
        }
    }


    func startAnimation() {
        animationView.play()
    }
    

    @objc func transitionToDetailViewController() {
        let detailViewController = DetailViewController()
        detailViewController.modalPresentationStyle = .popover
        present(detailViewController, animated: true)
    }
}
