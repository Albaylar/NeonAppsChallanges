import UIKit
import Lottie
import CoreImage

class DetailViewController: UIViewController {

    let originalImage = UIImage(named: "manzara")
    let imageView = UIImageView()
    let viewController = ViewController()
    var blurTimer: Timer?
    var blurProgress: CGFloat = 1.0
    let startStopButton = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    func setupUI() {
        view.backgroundColor = .black
        
        // Başlangıçta blurlu bir resim uygula
        imageView.image = applyBlurEffect(to: originalImage, progress: blurProgress) // Başlangıçta tamamen blur
        imageView.contentMode = .scaleAspectFill
        view.addSubview(imageView)
        imageView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalTo(view.layoutMarginsGuide)
        }
        
        viewController.animationView.animation = LottieAnimation.named("animation4")
        viewController.animationView.contentMode = .scaleAspectFit
        viewController.animationView.loopMode = .playOnce
        viewController.animationView.animationSpeed = 2.0 // İhtiyaca göre hızı ayarlayın

        view.addSubview(viewController.animationView)
        viewController.animationView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().inset(300)
            make.width.height.equalTo(200)
        }
        startStopButton.setTitle("Start/Stop", for: .normal)
        startStopButton.backgroundColor = .systemGreen
        startStopButton.layer.cornerRadius = 20
        startStopButton.addTarget(self, action: #selector(startStopAnimation), for: .touchUpInside)

        view.addSubview(startStopButton)
        startStopButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(viewController.animationView.snp.bottom).offset(50)
            make.height.equalTo(50)
            make.width.equalTo(100)
        }
    }
    
    func graduallyUnblur() {
        let duration: TimeInterval = 1.4 // Blurlamanın tamamen kaybolması için geçen süre
        let interval: TimeInterval = 0.05

        blurProgress -= CGFloat(interval / duration)
        if blurProgress >= 0.0 {
            imageView.image = applyBlurEffect(to: originalImage, progress: blurProgress)
        } else {
            blurTimer?.invalidate()
            blurTimer = nil
        }
    }
    
    func applyBlurEffect(to image: UIImage?, progress: CGFloat) -> UIImage? {
        guard let inputImage = image else { return nil }

        let blurredImage = applyBlurEffect(to: inputImage, radius: 10.0)
        return blendImages(original: inputImage, blurred: blurredImage, progress: progress)
    }

    func applyBlurEffect(to image: UIImage?, radius: Double) -> UIImage? {
        guard let inputImage = image else { return nil }

        let ciImage = CIImage(image: inputImage)
        let blurFilter = CIFilter(name: "CIGaussianBlur")
        blurFilter?.setValue(ciImage, forKey: kCIInputImageKey)
        blurFilter?.setValue(radius, forKey: kCIInputRadiusKey)

        if let outputImage = blurFilter?.outputImage {
            let context = CIContext(options: nil)
            let cgImage = context.createCGImage(outputImage, from: outputImage.extent)
            return UIImage(cgImage: cgImage!)
        }
        return nil
    }

    func blendImages(original: UIImage, blurred: UIImage?, progress: CGFloat) -> UIImage? {
        guard let blurredImage = blurred else { return nil }

        UIGraphicsBeginImageContextWithOptions(original.size, false, original.scale)
        original.draw(at: .zero)

        blurredImage.draw(at: .zero, blendMode: .normal, alpha: progress)
        let blendedImage = UIGraphicsGetImageFromCurrentImageContext()

        UIGraphicsEndImageContext()

        return blendedImage
    }
    
    
    
    @objc func startStopAnimation() {
        if viewController.animationView.isAnimationPlaying {
            viewController.animationView.stop()
            blurTimer?.invalidate()
            blurTimer = nil
        } else {
            viewController.animationView.play { [weak self] (finished) in
                if finished {
                    self?.startStopButton.isHidden = true
                    self?.viewController.animationView.isHidden = true
                    self?.blurTimer?.invalidate()
                    self?.blurTimer = nil
                }
            }
            blurTimer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { [weak self] timer in
                self?.graduallyUnblur()
            }
        }
    }
    
}

