//
//  AppDelegate.swift
//  RemoteConfigApp
//
//  Created by Furkan Deniz Albaylar on 21.11.2023.
//

import UIKit
import FirebaseCore
import SnapKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        window = UIWindow()
        FirebaseApp.configure()
        window?.rootViewController = ViewController()
        window?.makeKeyAndVisible()
        return true
    }



}

