//
//  ViewController.swift
//  RemoteConfigApp
//
//  Created by Furkan Deniz Albaylar on 21.11.2023.
//

import UIKit
import SnapKit
import FirebaseRemoteConfig

class ViewController: UIViewController {

    let imageView = UIImageView()

    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        fetchRemoteConfig()
    }

    func setupUI() {
        view.backgroundColor = .white
        imageView.image = UIImage(systemName: "photo")
        view.addSubview(imageView)
        imageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(100)
            make.left.right.equalToSuperview().inset(40)
            make.height.equalTo(200)
        }
        let label = UILabel()
        label.text = "Eurovision Song Contest"
        label.textAlignment = .center
        label.textColor = .blue
        view.addSubview(label)
        label.snp.makeConstraints { make in
            make.top.equalTo(imageView.snp.bottom).offset(100)
            make.left.right.width.equalToSuperview().inset(40)
            make.height.equalTo(50)
        }
        let label2 = UILabel()
        label2.text = "2022"
        label2.textAlignment = .center
        label2.textColor = .red
        view.addSubview(label2)
        label2.snp.makeConstraints { make in
            make.top.equalTo(label.snp.bottom).offset(40)
            make.left.right.width.equalToSuperview().inset(40)
            make.height.equalTo(50)
        }
        
    }

    func fetchRemoteConfig() {
        let remoteConfig = RemoteConfig.remoteConfig()
        let remoteConfigSettings = RemoteConfigSettings()
        remoteConfigSettings.minimumFetchInterval = 0
        remoteConfig.configSettings = remoteConfigSettings

        remoteConfig.fetch { (status, error) in
            if status == .success {
                print("Config fetched!")
                remoteConfig.activate { (_, _) in
                    self.applyConfigValues()
                }
            } else {
                print("Config fetch failed with error: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
    }

    func applyConfigValues() {
        let remoteConfig = RemoteConfig.remoteConfig()
        let isImageHidden = remoteConfig["isImageHidden"].boolValue

        DispatchQueue.main.async {
            self.imageView.isHidden = isImageHidden
        }
    }
}

