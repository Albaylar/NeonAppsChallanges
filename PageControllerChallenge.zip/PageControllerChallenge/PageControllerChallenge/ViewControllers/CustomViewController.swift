//
//  CustomViewController.swift
//  PageControllerChallenge
//
//  Created by Furkan Deniz Albaylar on 2.11.2023.
//

import UIKit

class CustomViewController: UIViewController {
    var pageContent: PageContent?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white

        guard let pageContent = pageContent else { return }

        let titleLabel = UILabel()
        titleLabel.text = pageContent.title
        titleLabel.numberOfLines = 0 // Birden fazla satır için uygun hale getirir
        titleLabel.textAlignment = .center // Metni merkeze hizalar
        titleLabel.adjustsFontSizeToFitWidth = true // Metni sığdırmak için boyutu ayarlar
        titleLabel.minimumScaleFactor = 0.5 // Minimum ölçek faktörü
        titleLabel.font = .boldSystemFont(ofSize: 30)
        view.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(view.snp.top).offset(100)
            make.left.equalTo(view.snp.left).offset(20) // Sol kenardan boşluk bırakır
            make.right.equalTo(view.snp.right).offset(-20) // Sağ kenardan boşluk bırakır
        }

        let subtitleLabel = UILabel()
        subtitleLabel.text = pageContent.subTitle
        subtitleLabel.textColor = .white
        subtitleLabel.numberOfLines = 0 // Birden fazla satır için uygun hale getirir
        subtitleLabel.textAlignment = .center // Metni merkeze hizalar
        subtitleLabel.adjustsFontSizeToFitWidth = true // Metni sığdırmak için boyutu ayarlar
        subtitleLabel.minimumScaleFactor = 0.5 // Minimum ölçek faktörü
        view.addSubview(subtitleLabel)
        subtitleLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(titleLabel.snp.bottom).offset(20)
            make.left.equalTo(view.snp.left).offset(20) // Sol kenardan boşluk bırakır
            make.right.equalTo(view.snp.right).offset(-20) // Sağ kenardan boşluk bırakır
        }

        let imageView = UIImageView()
        imageView.image = pageContent.image
        view.addSubview(imageView)
        imageView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(subtitleLabel.snp.bottom).offset(20)
            make.width.equalTo(300)
            make.height.equalTo(300)
        }

    }
}
