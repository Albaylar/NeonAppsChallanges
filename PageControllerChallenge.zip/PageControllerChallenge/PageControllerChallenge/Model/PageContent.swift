//
//  PageContent.swift
//  PageControllerChallenge
//
//  Created by Furkan Deniz Albaylar on 2.11.2023.
//

import Foundation
import UIKit

struct PageContent {
    var title : String
    var subTitle : String
    var image : UIImage?
}
