//
//  Global.swift
//  FirebaseAuthApp
//
//  Created by Furkan Deniz Albaylar on 17.11.2023.
//

import Foundation

class Global {
    static let shared = Global()
    var feedItems: [FeedItem] = []
    
}
