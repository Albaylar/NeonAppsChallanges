//
//  DetailViewController.swift
//  FirebaseAuth
//
//  Created by Furkan Deniz Albaylar on 13.11.2023.
//

import UIKit

class DetailViewController: UIViewController {

    override func viewDidLoad() {
        
        super.viewDidLoad()
        view.backgroundColor = .systemRed

        
    }
    func setupUI(){
        
    }
    

}
