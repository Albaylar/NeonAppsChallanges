//
//  CollectionViewCell.swift
//  FirebaseAuthApp
//
//  Created by Furkan Deniz Albaylar on 15.11.2023.
//

import UIKit
import SDWebImage



class FeedCell: UICollectionViewCell {
    
    static let identifier = "customCell"
    var emailLabel = UILabel()
    let feedImage = UIImageView()
    let descriptionLabel = UILabel()
    let commentLine = UIButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI(){
        emailLabel.textAlignment = .left
        emailLabel.backgroundColor = .white
        emailLabel.textAlignment = .center
        contentView.addSubview(emailLabel)
        emailLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(10)
            make.right.left.width.equalToSuperview().inset(1)
            make.height.equalTo(50)
        }
        feedImage.contentMode = .scaleAspectFill
        feedImage.layer.cornerRadius = 8
        feedImage.backgroundColor = .blue
        feedImage.clipsToBounds = true
        contentView.addSubview(feedImage)
        feedImage.snp.makeConstraints { make in
            make.top.equalTo(emailLabel.snp.bottom).offset(10)
            make.right.left.width.equalToSuperview().inset(1)
            make.height.equalTo(300)
        }
        descriptionLabel.backgroundColor = .white
        descriptionLabel.textAlignment = .left
        
        contentView.addSubview(descriptionLabel)
        descriptionLabel.snp.makeConstraints { make in
            make.top.equalTo(feedImage.snp.bottom).offset(10)
            make.right.left.width.equalToSuperview().inset(1)
            make.height.equalTo(20)
        }
        commentLine.backgroundColor = .darkGray
        commentLine.layer.cornerRadius = 10
        commentLine.setTitle("Add a Comment", for: .normal)
        commentLine.addTarget(self, action: #selector(commentLineTapped), for: .touchUpInside)
        
        contentView.addSubview(commentLine)
        commentLine.snp.makeConstraints { make in
            make.top.equalTo(descriptionLabel.snp.bottom).offset(5)
            make.right.left.width.equalToSuperview().inset(10)
            make.height.equalTo(25)
        }
        
        
        
    }
    func configure(with feedItem: FeedItem) {
        emailLabel.text = feedItem.postedBy
        descriptionLabel.text = feedItem.postComment
        feedImage.sd_setImage(with: URL(string: feedItem.imageUrl))
    }
    @objc func commentLineTapped(){
        NotificationCenter.default.post(name: Notification.Name("CommentButtonTapped"), object: self)

    }
}

    
    
    
        

    

