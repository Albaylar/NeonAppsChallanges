//
//  CommentViewController.swift
//  FirebaseAuthApp
//
//  Created by Furkan Deniz Albaylar on 17.11.2023.
//


import UIKit
import Firebase
import SnapKit

class CommentViewController: UIViewController {
    var comments: [String] = []
    let textField = UITextField()
    let tableView = UITableView()
    var postId: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        fetchComments()
    }

    func setupUI() {
        textField.placeholder = "Add A Comment"
        textField.layer.cornerRadius = 20
        textField.borderStyle = .roundedRect
        textField.textColor = .white
        textField.backgroundColor = .lightGray
        view.addSubview(textField)
        textField.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20)
            make.right.left.width.equalToSuperview().inset(10)
            make.height.equalTo(40)
        }

        let textSendButton = UIButton()
        textSendButton.setTitle("Send", for: .normal)
        textSendButton.backgroundColor = .systemRed
        textSendButton.addTarget(self, action: #selector(sendButtonTapped), for: .touchUpInside)
        textSendButton.layer.cornerRadius = 10
        view.addSubview(textSendButton)
        textSendButton.snp.makeConstraints { make in
            make.top.equalTo(textField.snp.bottom).offset(10)
            make.centerX.equalToSuperview()
            make.right.left.width.equalToSuperview().inset(30)
            make.height.equalTo(30)
        }

        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "commentCell")

        view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.top.equalTo(textSendButton.snp.bottom).offset(10)
            make.right.left.bottom.width.equalToSuperview().inset(5)
        }
    }

    

    func addComment(_ comment: String) {
        comments.append(comment)
        Firestore.firestore().collection("posts").document(postId!).updateData(["comments" : comments]) { error in
            if error != nil {
                print(error)
            }
        }
        tableView.reloadData()
    }

    func fetchComments() {
        guard let postId = postId else {
            return
        }
        let firestoreDatabase = Firestore.firestore()

        firestoreDatabase.collection("posts").document(postId).getDocument { [weak self] document, error in
            if let error = error {
                print("Error fetching document: \(error.localizedDescription)")
                return
            }

            guard let document = document, document.exists else {
                print("Document does not exist.")
                return
            }
            
            self?.comments.removeAll()
            if let comments = document["comments"] as? [String] {
                self?.comments = comments
                DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
            }
        }
    }
    @objc func sendButtonTapped() {
        guard let commentText = textField.text, !commentText.isEmpty else {
            return
        }

        addComment(commentText)
        textField.text = ""
    }

}

extension CommentViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return comments.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "commentCell", for: indexPath)
        cell.textLabel?.text = comments[indexPath.row]
        return cell
    }
}



