//
//  ViewController.swift
//  FirebaseAuth
//
//  Created by Furkan Deniz Albaylar on 13.11.2023.
//

import UIKit
import FirebaseAuth

class ViewController: UIViewController {
    static let shared = ViewController()
    let emailTextField = UITextField()
    let passwordTextField = UITextField()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    func setupUI(){
        view.backgroundColor = .white
        
        emailTextField.placeholder = "Please Enter a email"
        emailTextField.borderStyle = .roundedRect
        emailTextField.layer.cornerRadius = 20
        emailTextField.keyboardType = .emailAddress
        emailTextField.autocapitalizationType = .none


        view.addSubview(emailTextField)
        emailTextField.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(200)
            make.centerX.equalToSuperview()
            make.right.left.width.equalToSuperview().inset(50)
            make.height.equalTo(50)
        }
        
        passwordTextField.placeholder = "Please Enter a password"
        passwordTextField.borderStyle = .roundedRect
        passwordTextField.layer.cornerRadius = 100
        passwordTextField.isSecureTextEntry = true

        view.addSubview(passwordTextField)
        passwordTextField.snp.makeConstraints { make in
            make.top.equalTo(emailTextField.snp.bottom).offset(10)
            make.centerX.equalToSuperview()
            make.right.left.width.equalToSuperview().inset(50)
            make.height.equalTo(50)
        }
        
        let registerButton = UIButton()
        registerButton.setTitle("Register", for: .normal)
        registerButton.backgroundColor = .red
        registerButton.layer.cornerRadius = 25
        view.addSubview(registerButton)
        registerButton.addTarget(self, action: #selector(registeredButtonClicked), for: .touchUpInside)
        registerButton.snp.makeConstraints { make in
            make.top.equalTo(passwordTextField.snp.bottom).offset(20)
            make.centerX.equalToSuperview()
            make.right.left.width.equalToSuperview().inset(70)
            make.height.equalTo(50)
        }
        
        let textButton = UIButton()
        textButton.setTitle("Have you registered before?", for: .normal)
        textButton.setTitleColor(.red, for: .normal)
        textButton.backgroundColor = .clear
        textButton.addTarget(self, action: #selector(textButtonClicked), for: .touchUpInside)
        view.addSubview(textButton)
        textButton.snp.makeConstraints { make in
            make.top.equalTo(registerButton.snp.bottom).offset(10)
            make.centerX.equalToSuperview()
            make.right.left.width.equalToSuperview().inset(70)
            make.height.equalTo(50)
        }
        
        
    }
    

    @objc func textButtonClicked(){
        let loginViewController = LoginViewController()
        loginViewController.modalPresentationStyle = .fullScreen
        present(loginViewController, animated: true)

    }
    
    @objc func registeredButtonClicked() {
        guard let email = emailTextField.text, let password = passwordTextField.text else {
            print("Invalid email or password")
            return
        }

        // Validate email format
        if !isValidEmail(email) {
            print("Invalid email format")
            let alert = UIAlertController(title: "Alert", message: "Invalid email format.", preferredStyle: .alert)
            
            let okButton = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(okButton)
            
            // Present the alert
            self.present(alert, animated: true, completion: nil)
            return
        }

        Auth.auth().createUser(withEmail: email, password: password) { [weak self] authResult, error in
            if let error = error {
                print("Error registering user: \(error.localizedDescription)")
            } else {
                print("User registered successfully")
                
                // Send verification email
                Auth.auth().currentUser?.sendEmailVerification(completion: { error in
                    if let error = error {
                        print("Error sending verification email: \(error.localizedDescription)")
                    } else {
                        print("Verification email sent successfully")
                        
                        // Navigate to the next screen (e.g., email verification screen)
                        let verificationViewController = VerificationViewController()
                        self?.present(verificationViewController, animated: true)
                    }
                })
            }
        }
    }

    // Helper function to validate email format
    func isValidEmail(_ email: String) -> Bool {
        // Use a regular expression to check the email format
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }

}

