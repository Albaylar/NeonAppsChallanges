//
//  VerificationViewController.swift
//  FirebaseAuthApp
//
//  Created by Furkan Deniz Albaylar on 14.11.2023.
//

import UIKit
import FirebaseAuth

class VerificationViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    func setupUI() {
        view.backgroundColor = .white

        let titleLabel = UILabel()
        titleLabel.text = "Email Verification"
        titleLabel.font = UIFont.boldSystemFont(ofSize: 24)
        titleLabel.textAlignment = .center
        view.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(100)
            make.centerX.equalToSuperview()
        }

        let descriptionLabel = UILabel()
        descriptionLabel.text = "Please check your email for a verification link. If you haven't received it, you can tap the button below to resend the email."
        descriptionLabel.numberOfLines = 0
        descriptionLabel.textAlignment = .center
        view.addSubview(descriptionLabel)
        descriptionLabel.snp.makeConstraints { make in
            make.top.equalTo(titleLabel.snp.bottom).offset(100)
            make.left.right.equalToSuperview().inset(20)
        }

        let resendButton = UIButton()
        resendButton.setTitle("Resend Verification Email", for: .normal)
        resendButton.backgroundColor = .systemBlue
        resendButton.layer.cornerRadius = 20
        resendButton.addTarget(self, action: #selector(resendButtonClicked), for: .touchUpInside)
        view.addSubview(resendButton)
        resendButton.snp.makeConstraints { make in
            make.top.equalTo(descriptionLabel.snp.bottom).offset(20)
            make.centerX.equalToSuperview()
            make.width.equalTo(250)
            make.height.equalTo(50)
        }
    }

    @objc func resendButtonClicked() {
        // Resend the verification email
        Auth.auth().currentUser?.sendEmailVerification(completion: { error in
            if let error = error {
                print("Error resending verification email: \(error.localizedDescription)")
            } else {
                print("Verification email resent successfully")
            }
        })
    }
}

