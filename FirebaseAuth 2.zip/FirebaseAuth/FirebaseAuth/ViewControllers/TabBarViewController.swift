//
//  DetailViewController.swift
//  FirebaseAuthApp
//
//  Created by Furkan Deniz Albaylar on 14.11.2023.
//

import UIKit
import FirebaseFirestore

class TabBarViewController: UIViewController {


    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }

    func setupUI() {
        
        
        let tabbar = UITabBarController()
        tabbar.tabBar.layer.cornerRadius = 30
        tabbar.tabBar.layer.opacity = 1
        tabbar.tabBar.backgroundColor = .darkGray
        let feedVC = FeedViewController()
        feedVC.tabBarItem = UITabBarItem(tabBarSystemItem: .bookmarks, tag: 0)
        
        let uploadVC = UploadImageViewController()  
        uploadVC.tabBarItem = UITabBarItem(tabBarSystemItem: .more, tag: 1)
        
        view.backgroundColor = .white
        let viewControllers = [feedVC, uploadVC]
        tabbar.viewControllers = viewControllers
        self.addChild(tabbar)
        self.view.addSubview(tabbar.view)
        tabbar.view.frame = self.view.frame
 
    }
}



