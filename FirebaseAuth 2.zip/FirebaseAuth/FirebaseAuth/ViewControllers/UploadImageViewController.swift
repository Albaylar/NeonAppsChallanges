//
//  UploadImageViewController.swift
//  FirebaseAuthApp
//
//  Created by Furkan Deniz Albaylar on 14.11.2023.
//

import UIKit
import FirebaseFirestore
import FirebaseStorage
import FirebaseAuth


class UploadImageViewController: UIViewController {
    
    let photo = UIImageView()
    
    var commentTextField = UITextField()
    
    let progressView = UIProgressView()
    
    let feedVC = FeedViewController()
    
    let uuid = UUID().uuidString
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    func setupUI(){
        photo.image = UIImage(named: "selectImage")
        photo.contentMode = .scaleAspectFill
        photo.layer.cornerRadius = 75
        photo.clipsToBounds = true
        photo.tintColor = .blue
        photo.layer.borderWidth = 5
        photo.layer.borderColor = UIColor.black.cgColor
        
        view.addSubview(photo)
        photo.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(200)
            make.right.left.width.equalToSuperview().inset(20)
            make.height.equalTo(300)
        }
        let selectButton = UIButton()
        selectButton.setTitleColor(.blue, for: .normal)
        selectButton.addTarget(self, action: #selector(selectPhotoButtonTapped), for: .touchUpInside)
        view.addSubview(selectButton)
        selectButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(200)
            make.right.left.width.equalToSuperview().inset(20)
            make.height.equalTo(300)
        }
        
        progressView.progressViewStyle = .default
        progressView.isHidden = true
        view.addSubview(progressView)
        progressView.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.right.left.width.equalToSuperview().inset(20)
            make.height.equalTo(10)
        }
        
        commentTextField.placeholder = "Add a Comment"
        commentTextField.borderStyle = .roundedRect
        
        view.addSubview(commentTextField)
        commentTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(selectButton.snp.bottom).offset(20)
            make.right.left.width.equalToSuperview().inset(20)
            make.height.equalTo(50)
        }
        let uploadButton = UIButton()
        uploadButton.setTitle("Upload", for: .normal)
        uploadButton.setTitleColor(.white, for: .normal)
        uploadButton.backgroundColor = .gray
        
        uploadButton.addTarget(self, action: #selector(uploadButtonTapped), for: .touchUpInside)
        view.addSubview(uploadButton)
        uploadButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(commentTextField.snp.bottom).offset(20)
            make.right.left.width.equalToSuperview().inset(20)
            make.height.equalTo(50)
        }
        
        
    }
    
    @objc func selectPhotoButtonTapped() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    @objc func uploadButtonTapped() {
        
        
        let storage = Storage.storage()
        let storageReference = storage.reference()
        let mediaFolder = storageReference.child("Media")
        if let data = photo.image?.jpegData(compressionQuality: 0.5) {
            
            
            let imageReference = mediaFolder.child("\(uuid).jpg")
            imageReference.putData(data, metadata: nil) { metadata, error in
                if let error = error {
                    print("Error uploading image to Firebase Storage: \(error.localizedDescription)")
                } else {
                    imageReference.downloadURL { url, error in
                        if let error = error {
                            print("Error getting download URL: \(error.localizedDescription)")
                        } else {
                            guard let imageUrl = url?.absoluteString else {
                                print("Image URL is nil")
                                return
                            }
                            
                            let firestoreDataBase = Firestore.firestore()
                           // var firestoreReference: DocumentReference? = nil
                            let firestorePost = [
                                "postID": self.uuid,
                                "imageUrl": imageUrl,
                                "postedBy": Auth.auth().currentUser?.email ?? "",
                                "postComment": self.commentTextField.text ?? "",
                                "Date" : FieldValue.serverTimestamp(),
                                "Likes" : 0,
                                "comments": []
                            ] as [String : Any]
        
                            firestoreDataBase.collection("posts").document(self.uuid).setData(firestorePost) { error in
                                if let error = error {
                                    print("Error adding document: \(error.localizedDescription)")
                                } else {
                                    DispatchQueue.main.async {
                                        
                                        self.photo.image = UIImage(named: "selectImage")
                                        self.commentTextField.text = ""
                                        self.tabBarController?.selectedIndex = 0
                                        self.progressView.isHidden = false
                                        
                                    }
                                    
                                }
                            }
                        }
                    }
                }
            }
        } else {
            print("Error converting image to data.")
        }
    }
    
}
extension UploadImageViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            photo.image = selectedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}
