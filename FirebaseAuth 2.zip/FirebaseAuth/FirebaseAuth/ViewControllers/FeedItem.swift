//
//  FeedItem.swift
//  FirebaseAuthApp
//
//  Created by Furkan Deniz Albaylar on 16.11.2023.
//

import Foundation

struct FeedItem {
    let postId : String?
    let postedBy: String
    let imageUrl: String
    let postComment: String
    let comments: [String]?
//    let likes: Int

}

