//
//  aCollectionViewCell.swift
//  FirebaseAuthApp
//
//  Created by Furkan Deniz Albaylar on 16.11.2023.
//

import UIKit

class aCollectionViewCell: UICollectionViewCell {
    
}
