//
//  FeedViewController.swift
//  FirebaseAuthApp
//
//  Created by Furkan Deniz Albaylar on 14.11.2023.
//

import UIKit
import FirebaseFirestore




class FeedViewController: UIViewController {
    
    var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getData()
    }
    
    func setupUI() {
        let layout = UICollectionViewFlowLayout()
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        layout.scrollDirection = .vertical
        view.addSubview(collectionView)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.refreshControl?.isEnabled = false
        collectionView.register(FeedCell.self, forCellWithReuseIdentifier: FeedCell.identifier)
        
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            let spacing: CGFloat = 10
            let itemWidth = (view.frame.width - 3 * spacing)
            layout.itemSize = CGSize(width: itemWidth, height: itemWidth)
            layout.minimumInteritemSpacing = spacing
            layout.minimumLineSpacing = spacing
        }
        
        collectionView.snp.makeConstraints { make in
            make.edges.equalToSuperview().inset(10)
        }
    }
    
    func getData() {
        let firestoreDatabase = Firestore.firestore()
        
        let postRef = firestoreDatabase.collection("posts").order(by: "Date", descending: true)
        postRef.getDocuments { [weak self] snapshot, error in
            guard let self = self else { return }
            
            if let error = error {
                print("Error getting documents: \(error.localizedDescription)")
            } else {
                
                if let documents = snapshot?.documents {
                    var newPosts: [FeedItem] = []
                    
                    newPosts.removeAll(keepingCapacity: false)
                    
                    for document in documents {
                        let data = document.data()
                        let postID = data["postID"] as? String
                        let comments = data["comments"] as? [String]
                        
                        if let postedBy = data["postedBy"] as? String,
                           let imageUrl = data["imageUrl"] as? String,
                           let postComment = data["postComment"] as? String {
                            let post = FeedItem(postId: postID , postedBy: postedBy, imageUrl: imageUrl, postComment: postComment,comments: comments)
                            newPosts.append(post)
                        }
                    }
                    
                    Global.shared.feedItems = newPosts
                    
                    collectionView.reloadData()
                }
            }
        }
    }
    
    func addNewPost(post: FeedItem) {
        Global.shared.feedItems.insert(post, at: 0)
        DispatchQueue.main.async {
            self.collectionView.reloadData()
        }
    }
    @objc func handleCommentButtonTap(sender: UIButton) {
        let commentVC = CommentViewController()
        let post = Global.shared.feedItems[sender.tag]
        commentVC.postId = post.postId
        commentVC.modalPresentationStyle = .pageSheet
        present(commentVC, animated: true)
    }
    
}

extension FeedViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return Global.shared.feedItems.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: FeedCell.identifier, for: indexPath) as! FeedCell
        let feedItem = Global.shared.feedItems[indexPath.row]
        cell.commentLine.addTarget(self, action: #selector(handleCommentButtonTap), for: .touchUpInside)
        cell.commentLine.tag = indexPath.row
        cell.configure(with: feedItem)

        return cell
    }


    
    

}
extension FeedViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height*0.55)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5 // Dikeyde hücreler arası minimum mesafe (boşluk)
    }
}

