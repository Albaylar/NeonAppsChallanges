//
//  ViewController.swift
//  StackView
//
//  Created by Furkan Deniz Albaylar on 3.11.2023.
//

import UIKit

class ViewController: UIViewController {
    
    let stackView = UIStackView()
    let labelArray = ["Expelliarmus","Stupfy","Expecto Patronum","Avada Kedavra"]

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        addingView()
    }
    func setupUI(){
        stackView.axis = .vertical
        stackView.distribution = .fillEqually
        stackView.alignment = .fill
        stackView.spacing = 15
        
//        stackView
        view.addSubview(stackView)
        stackView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(300)
            make.width.equalTo(200)
            make.height.equalTo(300)
            
            
            
        }
    }
    func addingView(){
        for text in labelArray {
            let label = UILabel()
            label.text = text
            label.backgroundColor = .gray
            label.textAlignment = .center
            label.layer.cornerRadius = 10
            label.clipsToBounds = true
            stackView.addArrangedSubview(label)
            
        }
        
    }


}

