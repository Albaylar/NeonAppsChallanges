//
//  NextViewController.swift
//  HeroChallange
//
//  Created by Furkan Deniz Albaylar on 10.11.2023.
//

import UIKit

class NextViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
    }
    func setupUI(){
    
        let image = UIImageView()
        image.image = UIImage(named: "manzara")
        image.contentMode = .scaleAspectFill
        image.clipsToBounds = true
        image.layer.cornerRadius = 20
        view.addSubview(image)
        image.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(100)
            make.bottom.equalToSuperview().offset(-50)
            make.leading.equalToSuperview().offset(50)
            make.trailing.equalToSuperview().offset(-50)
        }
        let backButton = UIButton()
        backButton.setTitle("<Back", for: .normal)
        backButton.setTitleColor(.systemBlue, for: .normal)
        backButton.addTarget(self, action: #selector(goBack), for: .touchUpInside)
        view.addSubview(backButton)

        backButton.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(0)
            make.leading.equalToSuperview().offset(-13)
            make.width.equalTo(100)
            make.height.equalTo(40)
        }
        
    }
    @objc func goBack() {
        self.dismiss(animated: true, completion: nil)
    }
}
