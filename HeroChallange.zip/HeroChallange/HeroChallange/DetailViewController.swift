//
//  DetailViewController.swift
//  HeroChallange
//
//  Created by Furkan Deniz Albaylar on 10.11.2023.
//

import UIKit
import Hero
import SnapKit

class DetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupHero()
        
    }

    func setupUI() {
        view.backgroundColor = .black
        

        let upButton: UIButton = {
            let button = UIButton()
            button.setImage(UIImage(systemName: "arrowtriangle.up.circle.fill"), for: .normal)
            button.tintColor = .black
            button.backgroundColor = .systemBlue
            button.layer.cornerRadius = 20
            button.addTarget(self, action: #selector(upButtonTapped), for: .touchUpInside)
            return button
        }()

        let downButton: UIButton = {
            let button = UIButton()
            button.setImage(UIImage(systemName: "arrowtriangle.down.circle.fill"), for: .normal)
            button.tintColor = .black
            button.backgroundColor = .systemGreen
            button.layer.cornerRadius = 20
            button.addTarget(self, action: #selector(downButtonTapped), for: .touchUpInside)
            return button
        }()

        let leftButton: UIButton = {
            let button = UIButton()
            button.setImage(UIImage(systemName: "arrowtriangle.left.circle.fill"), for: .normal)
            button.tintColor = .black
            button.backgroundColor = .systemOrange
            button.layer.cornerRadius = 20
            button.addTarget(self, action: #selector(leftButtonTapped), for: .touchUpInside)
            return button
        }()

        let rightButton: UIButton = {
            let button = UIButton()
            button.setImage(UIImage(systemName: "arrowtriangle.right.circle.fill"), for: .normal)
            button.tintColor = .black
            button.backgroundColor = .systemRed
            button.layer.cornerRadius = 20
            button.addTarget(self, action: #selector(rightButtonTapped), for: .touchUpInside)
            return button
        }()

        view.addSubview(upButton)
        view.addSubview(downButton)
        view.addSubview(leftButton)
        view.addSubview(rightButton)

        upButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(50)
            make.height.equalTo(100)
            make.width.equalTo(100)
        }

        downButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().offset(-50)
            make.height.equalTo(100)
            make.width.equalTo(100)
        }

        leftButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(50)
            make.height.equalTo(100)
            make.width.equalTo(100)
        }

        rightButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-50)
            make.height.equalTo(100)
            make.width.equalTo(100)
        }
        let backButton = UIButton()
        backButton.setTitle("<Back", for: .normal)
        backButton.setTitleColor(.systemBlue, for: .normal)
        backButton.addTarget(self, action: #selector(goBack), for: .touchUpInside)
        view.addSubview(backButton)

        backButton.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(0)
            make.leading.equalToSuperview().offset(-13)
            make.width.equalTo(100)
            make.height.equalTo(40)
        }
    
    
    }

    func setupHero() {
        
        hero.isEnabled = true
       // hero.modalAnimationType = .selectBy(presenting: .slide(direction: .left), dismissing: .slide(direction: .right))
    }

    @objc func upButtonTapped() {
        let nextViewController = NextViewController()
        
        nextViewController.hero.isEnabled = true
        nextViewController.hero.modalAnimationType = .selectBy(presenting: .slide(direction: .down), dismissing: .slide(direction: .up))
        present(nextViewController, animated: true, completion: nil)
    }
    @objc func downButtonTapped(){
        let nextViewController = NextViewController()
        
        nextViewController.hero.isEnabled = true
        nextViewController.hero.modalAnimationType = .selectBy(presenting: .slide(direction: .up), dismissing: .slide(direction: .down))
        present(nextViewController, animated: true, completion: nil)
        
    }
    @objc func leftButtonTapped(){
        let nextViewController = NextViewController()
        
        nextViewController.hero.isEnabled = true
        nextViewController.hero.modalAnimationType = .selectBy(presenting: .slide(direction: .right), dismissing: .slide(direction: .left))
        present(nextViewController, animated: true, completion: nil)
        
    }
    @objc func rightButtonTapped(){
        let nextViewController = NextViewController()
        
        nextViewController.hero.isEnabled = true
        nextViewController.hero.modalAnimationType = .selectBy(presenting: .slide(direction: .left), dismissing: .slide(direction: .right))
        present(nextViewController, animated: true, completion: nil)
        
    }
    @objc func goBack() {
        self.dismiss(animated: true, completion: nil)
    }
    

    
}

