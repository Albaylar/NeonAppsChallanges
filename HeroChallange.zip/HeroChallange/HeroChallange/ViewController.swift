//
//  ViewController.swift
//  HeroChallange
//
//  Created by Furkan Deniz Albaylar on 10.11.2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI(){
        view.backgroundColor = .black
        
     let welcomeLabel = UILabel()
        welcomeLabel.text = "Welcome to the maze"
        welcomeLabel.font = UIFont.boldSystemFont(ofSize: 18)
        welcomeLabel.textColor = .systemBlue
        welcomeLabel.textAlignment = .center
        welcomeLabel.layer.cornerRadius = 20
        
        
        view.addSubview(welcomeLabel)
        welcomeLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(400)
            make.width.equalTo(400)
            make.height.equalTo(50)
        }
        let nextButton = UIButton()
        nextButton.setTitle("Next", for: .normal)
        nextButton.addTarget(self, action: #selector(nextButtonTapped), for: .touchUpInside)
        nextButton.backgroundColor = .systemBlue
        nextButton.layer.cornerRadius = 20
        nextButton.tintColor = .systemBlue
        
        view.addSubview(nextButton)
        nextButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(welcomeLabel.snp.bottom).offset(100)
            make.width.equalTo(100)
            make.height.equalTo(50)
        }
        
        
        
    }
    @objc func nextButtonTapped(){
        let detail = DetailViewController()
        detail.modalPresentationStyle = .popover
        present(detail, animated: true)
    }


}

