//
//  ViewController.swift
//  The Wicked Queen
//
//  Created by Furkan Deniz Albaylar on 1.11.2023.
//

import UIKit

class ViewController: UIViewController {
    
    let nameTextField = UITextField()
    let emailTextField = UITextField()
    let phoneNumberTextField = UITextField()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        
        
    }
    func setupUI(){
        //Name TextField
        nameTextField.borderStyle = .roundedRect
        nameTextField.placeholder = "Please Enter a Name"
        nameTextField.delegate = self
        nameTextField.textColor = .red
        nameTextField.font =  UIFont.boldSystemFont(ofSize: 15)
        
        view.addSubview(nameTextField)
        
        nameTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(100)
            make.width.equalTo(200)
            make.height.equalTo(50)
        }
        //Email TextField
        emailTextField.borderStyle = .roundedRect
        emailTextField.placeholder = "Please Enter a email"
        emailTextField.delegate = self
        emailTextField.textColor = .blue
        emailTextField.font =  UIFont.italicSystemFont(ofSize: 15)
        
        view.addSubview(emailTextField)
        
        emailTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(nameTextField).offset(70)
            make.width.equalTo(200)
            make.height.equalTo(50)
        }
        // Password TextField
        phoneNumberTextField.borderStyle = .roundedRect
        phoneNumberTextField.placeholder = "Please Enter a PhoneNumber"
        phoneNumberTextField.delegate = self
        phoneNumberTextField.textColor = .green
        phoneNumberTextField.attributedPlaceholder = NSAttributedString(string: "Phone Number : ", attributes: [.underlineStyle: NSUnderlineStyle.single.rawValue])
        
        view.addSubview(phoneNumberTextField)
        
        phoneNumberTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(emailTextField).offset(70)
            make.width.equalTo(200)
            make.height.equalTo(50)
        }
    }


}
extension ViewController : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        nameTextField.resignFirstResponder()
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = phoneNumberTextField.text , let textRange = Range(range,in: text) {
            let newText = text.replacingCharacters(in: textRange, with: string)
            return newText.count <= 10
        }
        return true
        //return (textField.text?.count ?? 0) + string.count - range.length <= 10
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == emailTextField {
            if let email = textField.text {
                if isValidEmail(email) {
                    print("Email Girişi Başarılı ve uygun Format")
                } else {
                    let alert = UIAlertController(title: "Yanlış Email", message: "Email adresiniz Doğru Formatta değil", preferredStyle: .alert)
                    let okButton = UIAlertAction(title: "Ok", style: .cancel)
                    alert.addAction(okButton)
                    present(alert, animated: true, completion: nil)
                }
            }
        }
    

        func isValidEmail(_ email: String) -> Bool {
            let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
            let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
            return emailPred.evaluate(with: email)
        }
    }
}

