//
//  DetailViewController.swift
//  CollectionView
//
//  Created by Furkan Deniz Albaylar on 8.11.2023.
//

import UIKit

class DetailViewController: UIViewController {
    var selectedApp: [App] = []
    let appNameLabel = UILabel()
    let appIconImageView = UIImageView()
    let appCategoryLabel = UILabel()
    let releaseDateLabel = UILabel()
    let appstoreURLButton = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        displayAppDetails()
    }

    func setupUI() {
        appNameLabel.textAlignment = .center
        appNameLabel.font = UIFont.boldSystemFont(ofSize: 24)
        view.addSubview(appNameLabel)
        appNameLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(view.safeAreaLayoutGuide).offset(20)
        }

        appIconImageView.contentMode = .scaleAspectFit
        view.addSubview(appIconImageView)
        appIconImageView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(appNameLabel.snp.bottom).offset(50)
            make.width.equalTo(150)
            make.height.equalTo(150)
        }

        appCategoryLabel.textAlignment = .center
        appCategoryLabel.font = UIFont.systemFont(ofSize: 18)
        view.addSubview(appCategoryLabel)
        appCategoryLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(appIconImageView.snp.bottom).offset(50)
        }

        releaseDateLabel.textAlignment = .center
        releaseDateLabel.font = UIFont.systemFont(ofSize: 18)
        view.addSubview(releaseDateLabel)
        releaseDateLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(appCategoryLabel.snp.bottom).offset(50)
        }

        appstoreURLButton.setTitle("Open in App Store", for: .normal)
        appstoreURLButton.setTitleColor(.blue, for: .normal)
        appstoreURLButton.addTarget(self, action: #selector(openAppStore), for: .touchUpInside)
        view.addSubview(appstoreURLButton)
        appstoreURLButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(view.safeAreaLayoutGuide).offset(-20)
        }
    }

    func displayAppDetails() {
        guard let app = selectedApp.first else { return }
        appNameLabel.text = app.appName
        appIconImageView.image = app.appIcon
        appCategoryLabel.text = "Category: \(app.appCategory)"
        releaseDateLabel.text = "Release Date: \(app.releaseDate)"
    }

    @objc func openAppStore() {
        guard let appURL = selectedApp.first?.appstoreURL, UIApplication.shared.canOpenURL(appURL) else { return }
        UIApplication.shared.open(appURL, options: [:], completionHandler: nil)
    }
}

