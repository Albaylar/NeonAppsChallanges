//
//  App.swift
//  CollectionView
//
//  Created by Furkan Deniz Albaylar on 8.11.2023.
//
import Foundation
import UIKit

struct App {
    var appIcon: UIImage
    var appName: String
    var releaseDate: String
    var appCategory: String
    var appstoreURL: URL
}
