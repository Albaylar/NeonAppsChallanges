//
//  ViewController.swift
//  CollectionView
//
//  Created by Furkan Deniz Albaylar on 7.11.2023.
//

import UIKit
import SnapKit

class ViewController: UIViewController {
    
    var collectionView: UICollectionView!
    var imageView = UIImageView()
//    var appNameLabel = UILabel()
//    var categoryLabel = UILabel()
    
    
    
    var apps = [App]()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }

    func setupUI() {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .white
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(CustomCollectionViewCell.self, forCellWithReuseIdentifier: "Cell")
        collectionView.refreshControl = UIRefreshControl()
        collectionView.refreshControl?.addTarget(self, action: #selector(refreshData), for: .valueChanged)
        view.addSubview(collectionView)
        
        collectionView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(100)
            make.leading.equalToSuperview().offset(10)
            make.trailing.equalToSuperview().offset(10)
            make.width.equalTo(260)
            make.height.equalTo(700)
        }
        apps.append(App(appIcon: UIImage(named: "appIcon1")!, appName: "AI Rap & Music Generator", releaseDate: "2023-08-10", appCategory: "Music", appstoreURL: URL(string: "https://apps.apple.com/us/app/ai-voice-music-generator/id6447696368")!))
        apps.append(App(appIcon: UIImage(named: "appIcon2")!, appName: "Smart Cleaner", releaseDate: "2023-08-20", appCategory: "Utilities", appstoreURL: URL(string: "https://apps.apple.com/us/app/smart-cleaner-free-up-space/id1576477935")!))
        apps.append(App(appIcon: UIImage(named: "appIcon3")!, appName: "PDF Editor", releaseDate: "2023-09-05", appCategory: "Productivity", appstoreURL: URL(string: "https://apps.apple.com/tr/app/pdf-converter-reader-editor/id1623317186")!))
        apps.append(App(appIcon: UIImage(named: "appIcon4")!, appName: "AI Art Creator", releaseDate: "2023-09-15", appCategory: "Art", appstoreURL: URL(string: "https://apps.apple.com/tr/app/ai-art-generator-avatar/id6443530742")!))
        apps.append(App(appIcon: UIImage(named: "appIcon5")!, appName: "Snore Tracker", releaseDate: "2023-10-05", appCategory: "Health", appstoreURL: URL(string: "https://apps.apple.com/us/app/snore-sense/id6448513742")!))
        apps.append(App(appIcon: UIImage(named: "appIcon6")!, appName: "AI Face Dance", releaseDate: "2023-10-22", appCategory: "Entertainment", appstoreURL: URL(string: "https://apps.apple.com/us/app/ai-face-dance/id6455987517")!))
        apps.append(App(appIcon: UIImage(named: "appIcon7")!, appName: "AI Headshot Creator", releaseDate: "2023-10-30", appCategory: "Photography", appstoreURL: URL(string: "https://neonapps.co/references/ai-headshot-creator")!))
        apps.append(App(appIcon: UIImage(named: "appIcon8")!, appName: "Call Blocker", releaseDate: "2023-11-05", appCategory: "Utilities", appstoreURL: URL(string: "https://www.example.com/app8")!))
        apps.append(App(appIcon: UIImage(named: "appIcon9")!, appName: "Photo Editor", releaseDate: "2023-11-15", appCategory: "Photography", appstoreURL: URL(string: "https://www.example.com/app9")!))
    }
    @objc func refreshData(){
        collectionView.refreshControl?.endRefreshing()
    }

}

extension ViewController: UICollectionViewDataSource , UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return apps.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! CustomCollectionViewCell
        let app = apps[indexPath.row]

        cell.appIconImageView.image = app.appIcon
        cell.appNameLabel.text = app.appName
        cell.categoryLabel.text = app.appCategory

        return cell
    }



    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let apple = apps[indexPath.row]
        let detailVC = DetailViewController()
        detailVC.selectedApp = [apple]
        present(detailVC,animated: true)
    }

    func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        let app = apps[indexPath.row]
        
        let configuration = UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { actions -> UIMenu? in
            let share = UIAction(title: "Share", image: UIImage(systemName: "square.and.arrow.up")) { [weak self] action in
                self?.shareAppURL(app.appstoreURL)
            }
            return UIMenu(title: "", children: [share])
        }
        return configuration
    }

    func shareAppURL(_ url: URL) {
        let activityViewController = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view
        activityViewController.popoverPresentationController?.sourceRect = self.view.bounds
        activityViewController.popoverPresentationController?.permittedArrowDirections = []
        present(activityViewController, animated: true, completion: nil)
    }
    

}
extension ViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let itemWidth = collectionView.bounds.width - 10 // Genişlik koleksiyonun genişliğinden 20 birim daha az olacak şekilde ayarlandı.
        let itemHeight: CGFloat = 200
        return CGSize(width: itemWidth, height: itemHeight)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
    }
}




