import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var placeNameTextField: UITextField!
    @IBOutlet weak var haveVisitedSwitch: UISwitch!
    @IBOutlet weak var visitCountTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        retrieveData() // Retrieve data when the view is loaded
    }
    
    // Save data to UserDefaults
    func saveData() {
        let placeName = placeNameTextField.text ?? ""
        let haveVisited = haveVisitedSwitch.isOn
        let visitCount = Int(visitCountTextField.text ?? "0") ?? 0

        UserDefaults.standard.set(placeName, forKey: "placeName")
        UserDefaults.standard.set(haveVisited, forKey: "haveVisited")
        UserDefaults.standard.set(visitCount, forKey: "visitCount")
        
        // Show alert
        let alert = UIAlertController(title: "Success", message: "Data saved to UserDefaults", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
        print("Data saved to UserDefaults")
    }

    func retrieveData() {
        let placeName = UserDefaults.standard.string(forKey: "placeName")
        let haveVisited = UserDefaults.standard.bool(forKey: "haveVisited")
        let visitCount = UserDefaults.standard.integer(forKey: "visitCount")
        print("Data retrieved from UserDefaults")

        // Use the retrieved data as needed
        placeNameTextField.text = placeName
           haveVisitedSwitch.isOn = haveVisited
           visitCountTextField.text = String(visitCount)
    }



    @IBAction func SaveButtonTapped(_ sender: Any) {
        saveData()
    }
}
