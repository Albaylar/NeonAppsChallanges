//
//  ViewController.swift
//  ActivityIndicatorChallange
//
//  Created by Furkan Deniz Albaylar on 2.11.2023.
//

import UIKit

class ViewController: UIViewController {
    
    let indicator = UIActivityIndicatorView()
    let button = UIButton()
    let label = UILabel()
    var isAnimating = false
    var timer : Timer?
    var count = 0
    

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        
    }
    func setupUI(){
        view.addSubview(indicator)
        //indicator.isAnimating = true
        
        indicator.snp.makeConstraints { make in
            make.centerX.centerY.equalToSuperview()
            make.width.equalTo(100)
            make.height.equalTo(100)
        }
        view.addSubview(button)
        
        button.setTitle("Start A Counter", for: .normal)
        button.backgroundColor = .darkGray
        button.backgroundColor = .systemRed
        button.layer.cornerRadius = 20
        button.addTarget(self, action: #selector(tapButton), for: .touchUpInside)
        
        button.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(100)
            make.centerX.equalToSuperview()
            make.width.equalTo(200)
        }
        label.textAlignment = .center
        label.text = ""
        
        view.addSubview(label)
        label.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(indicator).offset(40)
            make.height.equalTo(100)
            make.width.equalTo(100)
        }
        
    }
    @objc func tapButton() {
            if isAnimating {
                indicator.stopAnimating()
                indicator.isHidden = true
                isAnimating = false
                timer?.invalidate()
                timer = nil
                //view.insertSubview(label, at: 2)
                
            } else {
                indicator.isHidden = false
                indicator.startAnimating()
                isAnimating = true
                label.text = "\(count)"
                timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(timerUpddate), userInfo: nil, repeats: true)
            }
        
        }
    @objc func timerUpddate(){
        if count < 100 {
            count += 1
            label.text = "\(count)"
            if count % 10 == 0 {
                indicator.color = .systemBlue
                label.textColor = .systemBlue
                if count % 20 == 0 {
                    indicator.color = .systemRed
                    label.textColor = .systemRed
                    if count % 30 == 0 {
                        indicator.color = .systemGreen
                        label.textColor = .systemGreen
                    }
                    
                }
            }
        }
        else {
            label.text = ""
            timer?.invalidate()
            isAnimating = false
            indicator.stopAnimating()
        }
    }


}

