//
//  ViewController.swift
//  OneSignalApp
//
//  Created by Furkan Deniz Albaylar on 24.11.2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .red
    }


}

