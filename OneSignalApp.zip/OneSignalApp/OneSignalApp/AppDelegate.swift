//
//  AppDelegate.swift
//  OneSignalApp
//
//  Created by Furkan Deniz Albaylar on 24.11.2023.
//

import UIKit
import OneSignalFramework


@main
class AppDelegate: UIResponder, UIApplicationDelegate {

var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow()
        window?.rootViewController = ViewController()
        window?.makeKeyAndVisible()
        // Remove this method to stop OneSignal Debugging
        OneSignal.Debug.setLogLevel(.LL_VERBOSE)
                 
                 // OneSignal initialization
        OneSignal.initialize("4f2b4fbf-9e4f-4841-8047-2affd24052ac", withLaunchOptions: launchOptions)
                 
                 // requestPermission will show the native iOS notification permission prompt.
                 // We recommend removing the following code and instead using an In-App Message to prompt for notification permission
        OneSignal.Notifications.requestPermission({ accepted in
            print("User accepted notifications: \(accepted)")
        }, fallbackToSettings: true)
                 
                 // Login your customer with externalId
                //   OneSignal.login("EXTERNAL_ID")
        return true
    }

 


}

