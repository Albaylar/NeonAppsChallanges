//
//  ViewController.swift
//  AladdinsProgressView
//
//  Created by Furkan Deniz Albaylar on 3.11.2023.
//

import UIKit

class ViewController: UIViewController {
    
    let progresView = UIProgressView()
    var minValue = 0
    var maxValue = 10
    var progressValue : Float = 0.0
    let button = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        
        
    }
    func setupUI(){
        view.addSubview(progresView)
        progresView.progressViewStyle = .bar
        progresView.center = view.center
        progresView.progressTintColor = .black
        progresView.backgroundColor = .systemBlue
        progresView.setProgress(0.0, animated: false)
        
        progresView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
            make.width.equalTo(300)
            make.height.equalTo(2)
        }
        view.addSubview(button)
        button.setTitle("Tap To İncrease", for: .normal)
        button.backgroundColor = .darkGray
        button.layer.cornerRadius = 20
        button.addTarget(self, action: #selector(tapButton), for: .touchUpInside)
        
        button.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(350)
            make.centerX.equalToSuperview()
            make.width.equalTo(200)
        }
    }
    @objc func tapButton(){
        if progressValue < 10 {
            progressValue += 1.0
            progresView.setProgress(progressValue/10, animated: true)
        } else {
            progressValue = 0.0
            progresView.setProgress(0.0, animated: false)
        }
    }


}

