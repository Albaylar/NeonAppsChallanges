//
//  ViewController.swift
//  DynamicsLinkNeonApps
//
//  Created by Furkan Deniz Albaylar on 23.11.2023.
//

import UIKit
import FirebaseDynamicLinks
import SnapKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    func setupUI() {
        view.backgroundColor = .white

        let button = UIButton()
        button.setTitle("Forward", for: .normal)
        button.layer.cornerRadius = 20
        button.backgroundColor = .systemBlue
        button.addTarget(self, action: #selector(handleDynamicLink), for: .touchUpInside)
        view.addSubview(button)

        button.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(300)
            make.centerX.equalToSuperview()
            make.width.equalTo(200)
            make.height.equalTo(100)
        }
    }

    @objc func handleDynamicLink() {
        guard let link = URL(string: "https://dynamicslinkneonapps.page.link/furkan") else { return }

        let dynamicLinks = DynamicLinks.dynamicLinks()
        dynamicLinks.handleUniversalLink(link) { (dynamicLink, error) in
            if let dynamicLink = dynamicLink, let url = dynamicLink.url {
                print("Handled a dynamic link: \(url)")

                // URL'yi tarayıcıda aç
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }
    }

}


