//
//  ViewController.swift
//  ScrollView
//
//  Created by Furkan Deniz Albaylar on 3.11.2023.
//

import UIKit
import SnapKit

class ViewController: UIViewController {
    let scrollView = UIScrollView()
    var previousLabel: UILabel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        scrollView.delegate = self
    }

    func setupUI() {
        scrollView.isScrollEnabled = true
      
        view.addSubview(scrollView)
        scrollView.snp.makeConstraints { make in
            make.height.width.equalToSuperview()
        }
            for i in 0..<8 {
                let label = UILabel()
                label.text = "Label \(i + 1)"
                label.backgroundColor = .lightGray // Labelları görmeyi kolaylaştırmak için arka plan rengini ayarlayabilirsiniz
                label.textAlignment = .center
                scrollView.addSubview(label)
                
                label.snp.makeConstraints { make in
                    make.width.equalTo(350) // Labelların genişliğini belirleyebilirsiniz
                    make.height.equalTo(170) // Labelların yüksekliğini belirleyebilirsiniz
                    make.centerX.equalToSuperview()
                    if let previousLabel = previousLabel {
                        make.top.equalTo(previousLabel.snp.bottom).offset(20) // Labellar arasındaki boşluğu ayarlayabilirsiniz
                    } else {
                        make.top.equalTo(scrollView).offset(20) // İlk label için üst kenardan boşluk ayarlayabilirsiniz
                    }
                }
                
                previousLabel = label
            }
            
            // Son labellin alt kenarından scrollView'in alt kenarına boşluk bırakılması için constraint ekleyin
            if let lastLabel = previousLabel {
                lastLabel.snp.makeConstraints { make in
                    make.bottom.equalTo(scrollView).offset(-20) // Alt kenardan boşluk ayarlayabilirsiniz
                }
            }
        
    }
    
    
}
extension ViewController : UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offSetY = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height - scrollView.frame.size.height
        
        if offSetY > contentHeight {
        let alert = UIAlertController(title: "End of Scroll View", message: "You have reached the end of the scroll view.", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(okAction)
            self.present(alert, animated: true, completion: nil)
                }
            }
}


