//
//  ListCell.swift
//  RestfulApiChallange
//
//  Created by Furkan Deniz Albaylar on 23.11.2023.
//

import UIKit
import SnapKit
import SDWebImage

class ListCell: UITableViewCell {

    let titleLabel = UILabel()
    let genderLabel = UILabel()
    let characterImageView = UIImageView()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupUI() {
        contentView.backgroundColor = .white

        titleLabel.textAlignment = .center
        titleLabel.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        contentView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(10)
            make.centerX.equalToSuperview()
            make.height.equalTo(30)
        }

//        genderLabel.font = UIFont.systemFont(ofSize: 14, weight: .light)
//        genderLabel.textAlignment = .center
//        contentView.addSubview(genderLabel)
//        genderLabel.snp.makeConstraints { make in
//            make.top.equalTo(titleLabel.snp.bottom).offset(5)
//            make.centerX.equalToSuperview()
//            make.height.equalTo(20)
//        }
//
//        characterImageView.snp.makeConstraints { make in
//            make.top.equalTo(genderLabel.snp.bottom).offset(5)
//            make.centerX.equalToSuperview()
//            make.height.equalTo(150) 
//            make.width.equalTo(150)
//        }

    }

    func configure(with character: CharacterData) {
        titleLabel.text = character.name
//        genderLabel.text = character.gender
//
//        if let imageUrl = character.image, let url = URL(string: imageUrl) {
//            characterImageView.sd_setImage(with: url, completed: nil)
//        } else {
//            characterImageView.image = nil
//        }
    }
}


