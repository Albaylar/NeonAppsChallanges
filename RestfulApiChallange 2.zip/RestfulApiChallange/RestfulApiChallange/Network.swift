//
//  Network.swift
//  RestfulApiChallange
//
//  Created by Furkan Deniz Albaylar on 23.11.2023.
//
import Foundation

class Network {

    static let shared = Network()

    private init() {}

    func fetchData(completion: @escaping ([CharacterData]?, Error?) -> Void) {
        guard let url = URL(string: "https://rickandmortyapi.com/api/character/?page=1") else {
            return
        }
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                completion(nil, error)
                return
            }
            
            guard let data = data else {
                return
            }

            do {
                let decoder = JSONDecoder()
                let apiData = try decoder.decode(ApiData.self, from: data)
                let results = apiData.results ?? []
                completion(results, nil)
            } catch {
                print("Error decoding JSON: \(error.localizedDescription)")
                completion(nil, error)
            }
        }

        task.resume()
    }
}
