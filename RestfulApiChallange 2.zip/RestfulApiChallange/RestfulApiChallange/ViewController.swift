//
//  ViewController.swift
//  RestfulApiChallange
//
//  Created by Furkan Deniz Albaylar on 23.11.2023.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    let tableView = UITableView()
    var data: [CharacterData] = []
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        fetchData()
    }
    
    func setupUI() {
        view.backgroundColor = .white

        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(ListCell.self, forCellReuseIdentifier: "cell")
        view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview().offset(10)
        }
    }

    func fetchData() {
        if InternetManager.shared.isInternetActive() {
            Network.shared.fetchData { (data, error) in
                if let error = error {
                    print("Error: \(error.localizedDescription)")
                } else if let data = data {
                    self.data = data
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                        // Save data to Core Data after fetching from the network
                        for character in data {
                            self.saveToCoreData(character)
                        }
                    }
                }
            }
        } else {
            
            retrieveFromCoreData()
        }
    }

    private func saveToCoreData(_ data: CharacterData) {
        let context = appDelegate.persistentContainer.viewContext
        
        if let entity = NSEntityDescription.entity(forEntityName: "ListEntity", in: context) {
            // Bu satırı doğru bir şekilde saveToCoreData fonksiyonunun içine yerleştirin
            let listObject = NSManagedObject(entity: entity, insertInto: context) as! ListEntity
            
            // ListEntity'nin property'lerine değerleri atayın
            listObject.name = data.name
            listObject.gender = data.gender
            
            do {
                try context.save()
                print("Data saved to Core Data.")
            } catch {
                print("Error while saving data to Core Data: \(error.localizedDescription)")
            }
        }
    }


    private func retrieveFromCoreData() {
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "ListEntity")
        request.returnsObjectsAsFaults = false
        
        do {
            let results = try context.fetch(request)
            
            // Temizleme: Eski verileri temizle
            data.removeAll()
            
            for result in results as! [ListEntity] {
                // Yeni veriyi oluştur ve ekle
                let character = CharacterData(id: nil, name: result.name, status: nil, species: nil, type: nil, gender: result.gender, origin: nil, location: nil, image: nil, episode: nil, url: nil, created: nil)
                data.append(character)
            }
            
            // TableView'ı güncelle
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        } catch {
            print("Error while fetching data from Core Data: \(error.localizedDescription)")
        }
    }

}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ListCell
        let character = data[indexPath.row]
        cell.configure(with: character)
        return cell
    }
}


