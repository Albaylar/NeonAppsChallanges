//
//  CharacterData.swift
//  RestfulApiChallange
//
//  Created by Furkan Deniz Albaylar on 23.11.2023.
//

import Foundation

// MARK: - Character
struct ApiData: Codable {
    let results: [CharacterData]?
}

// MARK: - Result
struct CharacterData: Codable {
    let id: Int?
    var name, status, species, type: String?
    var gender: String?
    let origin, location: Location?
    let image: String?
    let episode: [String]?
    let url: String?
    let created: String?
}

// MARK: - Location
struct Location: Codable {
    let name: String?
    let url: String?
}
