//
//  ViewController.swift
//  WildWest
//
//  Created by Furkan Deniz Albaylar on 31.10.2023.
//

import UIKit
import SnapKit
import AVFoundation


class ViewController: UIViewController {
    let customTitle = UILabel()
    let dropdownButton = UIButton()
    var stackView = UIStackView()
    let dailySpecialsButton = UIButton()
    let vigilanteButton = UIButton()
    let blackSmithButton = UIButton()
    let additionalButton = UIButton()
    var buttonEnabled = false
    var tableView = UITableView()
    let bankRoberyButton = UIButton()
    var isRobberyInProgress = false
    var audioPlayer: AVAudioPlayer!


    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        setupStackView()
        stackView.isHidden = true
        additionalButton.isHidden = true
        setupAudioPlayer()
//        setTableView()
        
        
    }
//    func setTableView(){
//        tableView.dataSource = self
//        tableView.delegate = self
//        view.addSubview(tableView)
//    }

    func setupUI() {
        customTitle.text = "Wild West"
        customTitle.textAlignment = .center
        customTitle.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        view.addSubview(customTitle)
        customTitle.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(50)
            make.height.equalTo(50)
        }
        
        dropdownButton.setTitle("⬇️ Options ⬇️", for: .normal)
        dropdownButton.setTitleColor(.lightGray, for: .normal)
        dropdownButton.addTarget(self, action: #selector(dropDownButtonTapped), for: .touchUpInside)
        view.addSubview(dropdownButton)
        dropdownButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(customTitle).offset(20)
        }
        
        dailySpecialsButton.setTitle("Daily Specials", for: .normal)
        dailySpecialsButton.setTitleColor(.darkText, for: .normal)
        dailySpecialsButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        dailySpecialsButton.addTarget(self, action: #selector(dailySpecialsButtonTapped), for: .touchUpInside)
        dailySpecialsButton.titleLabel?.textAlignment = .center
        dailySpecialsButton.backgroundColor = .red
        dailySpecialsButton.layer.cornerRadius = 10
        dailySpecialsButton.layer.borderWidth = 2
        dailySpecialsButton.layer.borderColor = UIColor.systemBlue.cgColor
        dailySpecialsButton.alpha = 0.5
        dailySpecialsButton.layer.shadowColor = UIColor.black.cgColor
        dailySpecialsButton.layer.shadowOpacity = 0.5
        
        view.addSubview(dailySpecialsButton)
        dailySpecialsButton.snp.makeConstraints { make in
                    make.centerX.equalToSuperview()
                    make.bottom.equalTo(view.safeAreaLayoutGuide).offset(-50)
                    make.width.equalTo(200)
                    make.height.equalTo(50)
        }
        let image = UIImage(named: "specials1")
        dailySpecialsButton.setBackgroundImage(image, for: .normal)
        
        
        vigilanteButton.setTitle("Vigilante Button", for: .normal)
        vigilanteButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        vigilanteButton.setTitleColor(.black, for: .normal)
        vigilanteButton.backgroundColor = .orange
        vigilanteButton.tintColor = .purple
        vigilanteButton.layer.cornerRadius = 10
        vigilanteButton.addTarget(self, action: #selector(vigilanteButtonTapped), for: .touchDown)
        vigilanteButton.addTarget(self, action: #selector(vigilanteButtonReleased), for: .touchUpInside)
       // vigilanteButton.setImage(.specials1, for: .normal)
        view.addSubview(vigilanteButton)
        
        vigilanteButton.snp.makeConstraints { make in
                   make.centerX.equalToSuperview()
                   make.bottom.equalTo(dailySpecialsButton.snp.top).offset(-20)
                   make.width.equalTo(200)
                   make.height.equalTo(100)
        }
        
        blackSmithButton.setTitle("BlackSmith in Shop", for: .normal)
        blackSmithButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        blackSmithButton.setTitleColor(.blue, for: .normal)
        blackSmithButton.layer.cornerRadius = 10
        blackSmithButton.backgroundColor = .green
        blackSmithButton.tintColor = .darkGray
        blackSmithButton.addTarget(self, action: #selector(blackSmithButtonTapped), for: .touchUpInside)

        view.addSubview(blackSmithButton)
        
        blackSmithButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(vigilanteButton.snp.top).offset(-20)
            make.width.equalTo(200)
            make.height.equalTo(100)
        }
        additionalButton.setTitle("Additional Button", for: .normal)
        additionalButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        additionalButton.isEnabled = false
        additionalButton.backgroundColor = .darkGray
        additionalButton.setTitleColor(.systemRed, for: .normal)
        additionalButton.layer.cornerRadius = 10
        
        additionalButton.addTarget(self, action: #selector(AdditionalButtonTapped), for: .touchUpInside)
        
        view.addSubview(additionalButton)
        additionalButton.snp.makeConstraints { make in
                    make.centerX.equalToSuperview()
                    make.top.equalTo(blackSmithButton.snp.top).offset(-80)
                    make.width.equalTo(200)
                    make.height.equalTo(50)
                }
//        view.addSubview(tableView)
//
//        tableView.snp.makeConstraints { make in
//                    make.top.equalTo(additionalButton.snp.bottom).offset(20)
//                    make.leading.equalToSuperview()
//                    make.trailing.equalToSuperview()
//                    make.bottom.equalTo(view.safeAreaLayoutGuide)
//                }
        blackSmithButton.addTarget(self, action: #selector(toggleDisable), for: .touchUpInside)
        
        bankRoberyButton.setTitle("BankRoberyButton", for: .normal)
        bankRoberyButton.backgroundColor = .red
        bankRoberyButton.layer.cornerRadius = 10
        bankRoberyButton.addTarget(self, action: #selector(bankRobberButtonTapped), for: .touchUpInside)
        view.addSubview(bankRoberyButton)
        
        bankRoberyButton.snp.makeConstraints { make in
            make.top.equalTo(additionalButton).offset(-100)
            make.centerX.equalToSuperview()
            make.width.equalTo(200)
            make.height.equalTo(50)
            
        }
    }
                
            
    

    @objc func dropDownButtonTapped() {
        stackView.isHidden = !stackView.isHidden
    }

    @objc func dailySpecialsButtonTapped() {
        print("Daily Specials Button Tapped")
    }
    @objc func vigilanteButtonTapped(){
        vigilanteButton.backgroundColor = .yellow
    }
    @objc func vigilanteButtonReleased(){
        vigilanteButton.backgroundColor = .orange
    }
    @objc func blackSmithButtonTapped() {
        additionalButton.isHidden = !additionalButton.isHidden
    }
    @objc func AdditionalButtonTapped(){
        print("Additional Button Tapped")
    }
    @objc func toggleDisable() {
        buttonEnabled = !buttonEnabled
        additionalButton.isEnabled = buttonEnabled
        if additionalButton.isEnabled {
            additionalButton.setTitle("Disable Button", for: .normal)
        } else {
            additionalButton.setTitle("Enable Button", for: .normal)
        }
    }
    @objc func bankRobberButtonTapped() {
        if isRobberyInProgress {
            stopShakeSound()
            isRobberyInProgress = false
        } else {
            isRobberyInProgress = true
            playShakeSound()
            performShakeAnimation()
        }
    }

    func stopShakeSound() {
        audioPlayer.stop()
    }
    func setupBankRobberButton() {
        bankRoberyButton.addTarget(self, action: #selector(buttonHighlight), for: .touchDown)
        bankRoberyButton.addTarget(self, action: #selector(buttonNormal), for: .touchUpInside)
        bankRoberyButton.addTarget(self, action: #selector(buttonNormal), for: .touchDragExit)
    }

    func setupAudioPlayer() {
        guard let soundURL = Bundle.main.url(forResource: "sound", withExtension: "mp3") else {
            print("Sound file not found")
            return
        }

        do {
            audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
            audioPlayer.prepareToPlay()
        } catch {
            print("Error loading sound: \(error.localizedDescription)")
        }
    }



    @objc func buttonHighlight() {
        bankRoberyButton.setImage(UIImage(named: "progress_image"), for: .normal)
    }

    @objc func buttonNormal() {
        bankRoberyButton.setImage(nil, for: .normal)
    }

    func playShakeSound() {
        audioPlayer.play()
    }

    func performShakeAnimation() {
        let animation = CAKeyframeAnimation(keyPath: "transform.translation.x")
        animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        animation.duration = 0.6
        animation.values = [-20, 20, -20, 20, -10, 10, -5, 5, 0]
        bankRoberyButton.layer.add(animation, forKey: "shake")
    }



    @objc func optionButtonTapped(_ sender: UIButton) {
        if let optionTitle = sender.currentTitle {
            switch optionTitle {
            case "Call for Backup":
                print("Calling for backup!")
            case "Issue a Warning":
                print("Issuing a warning to the townspeople!")
            case "Other Option":
                print("Performing some other action!")
            default:
                break
            }
        }
        stackView.isHidden = true
    }
    
    func setupStackView() {
        let optionTitles = ["Call for Backup", "Issue Warning", "Other Option"]
        stackView.axis = .vertical
        stackView.spacing = 10
        stackView.alignment = .fill

        for title in optionTitles {
            let optionButton = UIButton()
            optionButton.setTitle(title, for: .normal)
            optionButton.setTitleColor(.black, for: .normal)
            optionButton.addTarget(self, action: #selector(optionButtonTapped), for: .touchUpInside)
            stackView.addArrangedSubview(optionButton)
        }

        view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.centerXAnchor.constraint(equalTo: dropdownButton.centerXAnchor).isActive = true
        stackView.topAnchor.constraint(equalTo: dropdownButton.bottomAnchor, constant: 10).isActive = true
    }
}
//extension ViewController : UITableViewDelegate {
//    
//}
//extension ViewController : UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 10
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
//        cell.textLabel?.text = "Row \(indexPath.row + 1)"
//        return cell
//    }
//    
//    
//}





