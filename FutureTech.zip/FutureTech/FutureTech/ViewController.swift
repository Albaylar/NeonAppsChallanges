//
//  ViewController.swift
//  FutureTech
//
//  Created by Furkan Deniz Albaylar on 30.10.2023.
//

import UIKit
import SnapKit
import SwiftUI

class ViewController: UIViewController {
    let deviceImageView = UIImageView(image: UIImage(systemName: "tv"))
    let deviceImageView2 = UIImageView(image: UIImage(systemName: "lamp.desk"))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
    }
    
    func setupUI() {
        // Title
        let title = UILabel ()
        title.text = "Future Tech"
        title.textAlignment = .center
        title.textColor = .systemBlue
        title.font = .boldSystemFont(ofSize: 35)
        self.view.addSubview(title)
        title.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(80)
            make.width.equalTo(200)
            make.height.equalTo(50)
        }
        
        
        
            let containerView = UIView()
        containerView.backgroundColor = .black
            
        
        view.addSubview(containerView)
        
        
            let container2 = UIView()
            container2.backgroundColor = .black
            
        

        view.addSubview(container2)
        // Device Image
        
        containerView.addSubview(deviceImageView)
        container2.addSubview(deviceImageView2)
        
        
        // Control Button
        let controlButton = UIButton()
        controlButton.backgroundColor = .systemBlue
        controlButton.setTitle("System Button", for: .normal)
        controlButton.addTarget(self, action: #selector(controlButtonTapped), for: .touchUpInside)
        self.view.addSubview(controlButton)
        
        let controlButton2 = UIButton()
        controlButton2.backgroundColor = .systemBlue
        controlButton2.setTitle("System Button", for: .normal)
        controlButton2.addTarget(self, action: #selector(control2ButtonTapped), for: .touchUpInside)
        self.view.addSubview(controlButton2)
        
        
        // SnapKit Constraints
        
        //-Title
        
      
        deviceImageView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(containerView.snp.top).offset(8)
            make.width.equalTo(100)
            make.height.equalTo(100)
        }
        controlButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(deviceImageView.snp.bottom).offset(20)
            make.width.equalTo(300)
            make.height.equalTo(50)
        }
        containerView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(title.snp.bottom).offset(40)
            make.width.equalTo(300)
            make.height.equalTo(115)
        }
        container2.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(controlButton.snp.bottom).offset(20)
            make.width.equalTo(300)
            make.height.equalTo(115)
        }
        deviceImageView2.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(container2.snp.top).offset(8)
            make.width.equalTo(100)
            make.height.equalTo(100)
        }
        controlButton2.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(deviceImageView2.snp.bottom).offset(20)
            make.width.equalTo(300)
            make.height.equalTo(50)
        }
        
        
        
        
    }
    @objc func controlButtonTapped(){
        if deviceImageView.image == UIImage(systemName: "tv") {
            deviceImageView.image = UIImage(systemName:"tv.fill")
        } else {
            deviceImageView.image = UIImage(systemName: "tv")
        }
        
    }
    @objc func control2ButtonTapped(){
        if deviceImageView2.image == UIImage(systemName: "lamp.desk") {
            deviceImageView2.image = UIImage(systemName:"lamp.desk.fill")
        } else {
            deviceImageView2.image = UIImage(systemName: "lamp.desk")
        }
        
    }

    
}



