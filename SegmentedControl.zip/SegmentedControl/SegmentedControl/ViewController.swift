//
//  ViewController.swift
//  SegmentedControl
//
//  Created by Furkan Deniz Albaylar on 2.11.2023.
//

import UIKit

class ViewController: UIViewController {
    
    let segmentedControl = UISegmentedControl()
    let control = UISegmentedControl(items: ["Neon Academy 2023","Neon","Apps"])
    

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        
    }
    func setupUI(){
        
        //control.selectedSegmentIndex = 0
        control.subviews[0].backgroundColor = UIColor(cgColor: .init(red: 1, green: 0, blue: 1, alpha: 1))
        control.subviews[1].backgroundColor = .systemRed
        control.subviews[2].backgroundColor = .systemBlue
        
        view.addSubview(control)
        
        control.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(70)
            make.centerX.equalToSuperview()
            //make.leading.equalToSuperview().offset(10)
            make.width.equalTo(200)
        }
        control.selectedSegmentTintColor = UIColor(red: 1, green: 0, blue: 1, alpha: 1) // Bright neon color
        control.addTarget(self, action: #selector(segmentControllerhasBeenChanged), for: .valueChanged)
    
        
        
    }
    @objc func segmentControllerhasBeenChanged(sender: UISegmentedControl) {
            switch sender.selectedSegmentIndex {
            case 0:
                print("Neon Academy 2023 selected")
                control.transform = CGAffineTransform(scaleX: 1.8, y: 1.8) // Increase the size
            case 1:
                print("Neon selected")
                control.transform = .identity // Reset the size
            case 2:
                print("Apps selected")
                control.transform = CGAffineTransform(scaleX: 0.7, y: 0.7) // Decrease the size
            default:
                break
            }
        }



}

